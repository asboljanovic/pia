/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Knjiga;
import entities.User;
import java.io.IOException;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class pretragaController {

    ArrayList<User> korisnici = sviKorisnici();
    ArrayList<User> korisniciIme = new ArrayList<>();
    ArrayList<User> korisniciPrezime = new ArrayList<>();
    ArrayList<User> korisniciUsername = new ArrayList<>();
    ArrayList<User> korisniciEmail = new ArrayList<>();

    private String ime;
    private String prezime;
    private String username;
    private String email;
    private String porukaIme = "", porukaPrezime = "", porukaUsername = "", porukaEmail = "";

    public void pretraga_ime() {
        if(ime.equals("")) {
              return;
          }
        if (korisniciIme.size() > 0) {
            korisniciIme.clear();
        }
        for(int i = 0; i < korisnici.size(); i++) {
            if(korisnici.get(i).getIme().equalsIgnoreCase(ime)) {
                korisniciIme.add(korisnici.get(i));
            }
        }
        if(korisniciIme.size()==0) {
            porukaIme = "Nema korisnika unetog imena!";
        }else {
            porukaIme = "";
        }

    }
      public void pretraga_prezime() {
          if(prezime.equals("")) {
              return;
          }
        if (korisniciPrezime.size() > 0) {
            korisniciPrezime.clear();
        }
        for(int i = 0; i < korisnici.size(); i++) {
            if(korisnici.get(i).getPrezime().equalsIgnoreCase(prezime)) {
                korisniciPrezime.add(korisnici.get(i));
            }
        }
        if(korisniciPrezime.size()==0) {
            porukaPrezime = "Nema korisnika unetog prezimena!";
        }else {
            porukaPrezime = "";
        }

    }
      public void pretraga_username() {
          if(username.equals("")) {
              return;
          }
        if (korisniciUsername.size() > 0) {
            korisniciUsername.clear();
        }
        for(int i = 0; i < korisnici.size(); i++) {
            if(korisnici.get(i).getUsername().equalsIgnoreCase(username)) {
                korisniciUsername.add(korisnici.get(i));
            }
        }
        if(korisniciUsername.size()==0) {
            porukaUsername = "Nema korisnika unetog username-a!";
        }else {
            porukaUsername = "";
        }

    }
       public void pretraga_email() {
           if(email.equals("")) {
              return;
          }
        if (korisniciEmail.size() > 0) {
            korisniciEmail.clear();
        }
        for(int i = 0; i < korisnici.size(); i++) {
            if(korisnici.get(i).getEmail().equalsIgnoreCase(email)) {
                korisniciEmail.add(korisnici.get(i));
            }
        }
        if(korisniciEmail.size()==0) {
            porukaEmail = "Nema korisnika unetog email-a!";
        }else {
            porukaEmail = "";
        }

    }
        public void nazad() throws IOException {
             porukaEmail = "";
            porukaIme = "";
            porukaPrezime = "";
            porukaUsername = "";
            ime = "";
            prezime = "";
            username = "";
            email = "";
            korisniciEmail.clear();
            korisniciIme.clear();
            korisniciPrezime.clear();
            korisniciUsername.clear();
    

        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

    }
        public void nazad1(String tip) throws IOException {
            porukaEmail = "";
            porukaIme = "";
            porukaPrezime = "";
            porukaUsername = "";
            ime = "";
            prezime = "";
            username = "";
            email = "";
            korisniciEmail.clear();
            korisniciIme.clear();
            korisniciPrezime.clear();
            korisniciUsername.clear();

       
        if (tip.equals("administrator")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml");

        } else if (tip.equals("moderator")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml");

        } else if (tip.equals("korisnik")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");

        } else {
            FacesContext.getCurrentInstance().getExternalContext().redirect("gost.xhtml");

        }

    }


    private ArrayList<User> sviKorisnici() {
        ArrayList<User> users = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(User.class);
        users = (ArrayList<User>) c.list();

        session.getTransaction().commit();
        session.close();

        return users;

    }

    public ArrayList<User> getKorisnici() {
        return korisnici;
    }

    public void setKorisnici(ArrayList<User> korisnici) {
        this.korisnici = korisnici;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPorukaIme() {
        return porukaIme;
    }

    public void setPorukaIme(String porukaIme) {
        this.porukaIme = porukaIme;
    }

    public String getPorukaPrezime() {
        return porukaPrezime;
    }

    public void setPorukaPrezime(String porukaPrezime) {
        this.porukaPrezime = porukaPrezime;
    }

    public String getPorukaUsername() {
        return porukaUsername;
    }

    public void setPorukaUsername(String porukaUsername) {
        this.porukaUsername = porukaUsername;
    }

    public String getPorukaEmail() {
        return porukaEmail;
    }

    public void setPorukaEmail(String porukaEmail) {
        this.porukaEmail = porukaEmail;
    }
    
    public ArrayList<User> getKorisniciIme() {
        return korisniciIme;
    }

    public void setKorisniciIme(ArrayList<User> korisniciIme) {
        this.korisniciIme = korisniciIme;
    }

    public ArrayList<User> getKorisniciPrezime() {
        return korisniciPrezime;
    }

    public void setKorisniciPrezime(ArrayList<User> korisniciPrezime) {
        this.korisniciPrezime = korisniciPrezime;
    }

    public ArrayList<User> getKorisniciUsername() {
        return korisniciUsername;
    }

    public void setKorisniciUsername(ArrayList<User> korisniciUsername) {
        this.korisniciUsername = korisniciUsername;
    }

    public ArrayList<User> getKorisniciEmail() {
        return korisniciEmail;
    }

    public void setKorisniciEmail(ArrayList<User> korisniciEmail) {
        this.korisniciEmail = korisniciEmail;
    }


}
