/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.User;
import java.io.IOException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */

@ManagedBean
@SessionScoped
public class promenaLozinkeController {
    
    private String username;
    private String old_password;
    private String new_password;
    private String confirm_new_password;
    private String poruka;

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getOld_password() {
        return old_password;
    }

    public void setOld_password(String old_password) {
        this.old_password = old_password;
    }

    public String getNew_password() {
        return new_password;
    }

    public void setNew_password(String new_password) {
        this.new_password = new_password;
    }

    public String getConfirm_new_password() {
        return confirm_new_password;
    }

    public void setConfirm_new_password(String confirm_new_password) {
        this.confirm_new_password = confirm_new_password;
    }
    
    public void promeni() throws IOException {
        
        if(!new_password.equals(confirm_new_password)) {
            poruka = "Unete lozinke se ne poklapaju!";
            return;
        }
        FacesContext fc = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) fc.getExternalContext().getSession(false);
        User user = (User) session.getAttribute("user");
        
        if(!old_password.equals(user.getPassword())) {
              poruka = "Stara lozinka je netačna!";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("username", user.getUsername())).uniqueResult();
          baseUser.setPassword(new_password);
          s.save(baseUser);
          s.getTransaction().commit();
          s.close();
          session.invalidate();
          poruka = "";
          
            FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");
     
      
    }
    
     public void nazad(String tip) throws IOException {
       
         poruka = "";
         confirm_new_password = "";
         new_password = "";
         old_password = "";
         username = "";
        
        
        if(tip.equals("administrator")) {
        FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml"); }
        else  if(tip.equals("moderator")) {
         FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml"); }
        else {
             FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");
        }       
        

    }
     public void nazadGost2() throws IOException {
     
           poruka = "";
         confirm_new_password = "";
         new_password = "";
         old_password = "";
         username = "";

        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

    }
}
