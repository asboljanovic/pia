/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Knjiga;
import entities.Komentar;
import java.io.IOException;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class stranicaController {
    
    ArrayList<Komentar> komentari = new ArrayList<>();
    private Knjiga knjiga = null;
    
    
    
   

   
      private ArrayList<Komentar> sviKomentari() {
        ArrayList<Komentar> kom = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Komentar.class);
        kom = (ArrayList<Komentar>) c.add(Restrictions.eq("idknjiga", knjiga.getIdknjiga())).list();

        session.getTransaction().commit();
        session.close();

        return kom;

    }
    
    public void idi_na_stranicu(int id) throws IOException {
        
        //nadji knjigu u sistemu i zapamti je
        
         SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        
        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", id)).uniqueResult();
        
        
        
        s.getTransaction().commit();
        s.close();
        
        if(baseKnjiga !=null) {
            knjiga = baseKnjiga;
        }
        
        if(sviKomentari() != null) {
        komentari = sviKomentari();
        } 
        
         FacesContext.getCurrentInstance().getExternalContext().redirect("stranicaKnjiga.xhtml");
       
       
        
    }
   

    public Knjiga getKnjiga() {
        return knjiga;
    }

    public void setKnjiga(Knjiga knjiga) {
        this.knjiga = knjiga;
    }

    public ArrayList<Komentar> getKomentari() {
        return komentari;
    }

    public void setKomentari(ArrayList<Komentar> komentari) {
        this.komentari = komentari;
    }
     
    
    
    
}
