/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Knjiga;
import entities.ZahtevKnjiga;
import entities.Zanr;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.file.UploadedFile;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class knjigaController {

    ArrayList<Knjiga> knjige = sveKnjige();
    ArrayList<Knjiga> knjigeZaPrikaz = sveKnjigePrikaz();
    ArrayList<ZahtevKnjiga> zahteviKnjiga = zahtevi();
    ArrayList<Knjiga> knjigeAutor = new ArrayList<Knjiga>();
    ArrayList<Knjiga> knjigeNaziv = new ArrayList<Knjiga>();
    ArrayList<Knjiga> knjigeZanr = new ArrayList<Knjiga>();
    private String autor;
    private String naziv;
    private String oznaceniZanr;
    private boolean pretragaAutor = false;
    private boolean pretragaNaziv = false;
    private boolean pretragaZanr = false;
    private String autorPoruka = "";
    private String nazivPoruka = "";
    private String oznaceniZanrPoruka = "";
    ArrayList<Zanr> zanrovi = sviZanrovi();
    private String zanr;
    private String zanrPoruka = "";
    private String zanrKnjige;
    private String zanrKnjigePoruka;
    ArrayList<String> nazivZanra = sviNazivZanra();
    private String nemaZanrova = "";
    private String postojiKnjigaSaZanrom = "";
    private boolean nemaA = false, nemaN = false;

    public StreamedContent getRealPhoto(byte[] photo) throws SQLException, IOException {

        if (photo != null) {
            InputStream is = new ByteArrayInputStream((byte[]) photo);
            DefaultStreamedContent newPhoto = new DefaultStreamedContent(is, "image/jpg");

            return newPhoto;
        }
        return null;
    }

    public void obrisati_zanr(String zanr) {

        for (int i = 0; i < knjige.size(); i++) {
            String bazaZanr = knjige.get(i).getZanr();
            if (bazaZanr.contains(",")) {
                String[] arrSplit = bazaZanr.split(",");

                if (arrSplit[0].equals(zanr)) {
                    postojiKnjigaSaZanrom = "Nije moguće brisanje označenog žanra jer postoji knjiga sa datim žanrom";
                    return;
                }

                if (arrSplit[1].equals(zanr)) {
                    postojiKnjigaSaZanrom = "Nije moguće brisanje označenog žanra jer postoji knjiga sa datim žanrom";
                    return;
                }

                if (arrSplit[0].equals(zanr)) {
                    postojiKnjigaSaZanrom = "Nije moguće brisanje označenog žanra jer postoji knjiga sa datim žanrom";
                    return;
                }

            } else {
                if (knjige.get(i).getZanr().equals(zanr)) {
                    postojiKnjigaSaZanrom = "Nije moguće brisanje označenog žanra jer postoji knjiga sa datim žanrom";
                    return;
                }
            }
        }

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(Zanr.class);
        Zanr z = (Zanr) c.add(Restrictions.eq("zanr", zanr)).uniqueResult();
        session.delete(z);
        session.flush();
        t.commit();
        session.close();
        postojiKnjigaSaZanrom = "Žanr obrisan";
        zanrovi = sviZanrovi();
        nazivZanra.remove(z.getZanr());
    }

    private ArrayList<String> sviNazivZanra() {
        ArrayList<String> svi = new ArrayList<String>();
        for (int i = 0; i < zanrovi.size(); i++) {
            svi.add(zanrovi.get(i).getZanr());
        }
        return svi;
    }

    private ArrayList<Zanr> sviZanrovi() {
        ArrayList<Zanr> zanrovi = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Zanr.class);
        zanrovi = (ArrayList<Zanr>) c.list();
        session.getTransaction().commit();
        session.close();

        return zanrovi;

    }

    public void dodaj_zanr() {
        if("".equals(zanr)) {
            
                return;
        }
        for (int i = 0; i < nazivZanra.size(); i++) {
            if (nazivZanra.get(i).equals(zanr)) {
                zanrPoruka = "Žanr već postoji u sistemu.";
                return;
            }
        }

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Zanr z = new Zanr();
        z.setZanr(zanr);
        nazivZanra.add(zanr);
        session.save(z);

        t.commit();
        session.close();
        zanrovi = sviZanrovi();
        zanrPoruka = "Žanr uspešno dodat";
        zanr = "";

    }

    public void pretraga_zanrom() {
        if (knjigeZanr.size() > 0) {
            knjigeZanr.clear();
        }
        if (knjigeZaPrikaz.size() > 0) {
            for (int i = 0; i < knjigeZaPrikaz.size(); i++) {
                String bazaZanr = knjigeZaPrikaz.get(i).getZanr();
                if (bazaZanr.contains(",")) {  //DA LI POSTOJI VISE ZANROVA-PODELJENI SU ZAREZOM
                    String[] arrSplit = bazaZanr.split(",");

                    if (arrSplit[0].equalsIgnoreCase(oznaceniZanr)) {
                        knjigeZanr.add(knjigeZaPrikaz.get(i));
                    }

                    if (arrSplit[1].equalsIgnoreCase(oznaceniZanr)) {
                        knjigeZanr.add(knjigeZaPrikaz.get(i));
                    }

                    if (arrSplit[0].equalsIgnoreCase(oznaceniZanr)) {
                        knjigeZanr.add(knjigeZaPrikaz.get(i));
                    }

                } else if (knjigeZaPrikaz.get(i).getZanr().equalsIgnoreCase(oznaceniZanr)) { // NE POSTOJI VISE ZANROVA, SAMO POREDI
                    knjigeZanr.add(knjigeZaPrikaz.get(i));
                }

            }
        }
        if (knjigeZanr.size() == 0) {
            oznaceniZanrPoruka = "Ne postoje knjige traženog žanra!";
            pretragaZanr = false;
            return;
        }
        oznaceniZanrPoruka = "";
        pretragaZanr = true;
        pretragaAutor = false;
        pretragaNaziv = false;
        oznaceniZanr = "";

    }

    public void pretraga_nazivom() {
        if (knjigeNaziv.size() > 0) {
            knjigeNaziv.clear();
        }

        if (knjigeZaPrikaz.size() > 0) {
            for (int i = 0; i < knjigeZaPrikaz.size(); i++) {

                if (knjigeZaPrikaz.get(i).getNaziv().equalsIgnoreCase(naziv)) { //AKO JE CEO NAZIV UNET
                    knjigeNaziv.add(knjigeZaPrikaz.get(i));
                } else { //UNET SAMO DELIMICAN NAZIV - DINAMICKO PRETRAZIVANJE
                    int velicinaUnetog = naziv.length();
                    int velicinaBaza = knjigeZaPrikaz.get(i).getNaziv().length();
                    if (velicinaBaza > velicinaUnetog) {
                        String bazirani = "";
                        for (int j = 0; j < velicinaUnetog; j++) {
                            bazirani += knjigeZaPrikaz.get(i).getNaziv().charAt(j);
                        }
                        if (bazirani.equalsIgnoreCase(naziv)) {
                            knjigeNaziv.add(knjigeZaPrikaz.get(i));
                        }
                    }
                }

            }
        }

        if (knjigeNaziv.size() == 0) {
            nazivPoruka = "Ne postoje knjige traženog naziva!";
            nemaN = true;
            pretragaNaziv = false;
            return;
        }
        nazivPoruka = "";
        nemaN = false;
        pretragaNaziv = true;
        pretragaAutor = false;
        pretragaZanr = false;
        naziv = "";

    }

    public void pretraga_autorom() {

        if (knjigeAutor.size() > 0) {
            knjigeAutor.clear();
        }

        if (knjigeZaPrikaz.size() > 0) {
            for (int i = 0; i < knjigeZaPrikaz.size(); i++) {
                String bazaAutor = knjigeZaPrikaz.get(i).getAutor();
                if (bazaAutor.contains(",")) { // AKO IMA VISE AUTORA - PODELJENI ZAREZOM
                    String[] arrSplit = bazaAutor.split(",");
                    int velicina = arrSplit.length;
                    for (int j = 0; j < velicina; j++) {
                        if (arrSplit[j].equalsIgnoreCase(autor)) { //UNET CEO AUTOR
                            knjigeAutor.add(knjigeZaPrikaz.get(i));
                        } else { // UNET SAMO DEO AUTORA - DINAMICKO PRETRZIVANJE
                            int velicinaUnetog = autor.length();
                            int velicinaBaza = arrSplit[j].length();
                            if (velicinaBaza > velicinaUnetog) {
                                String bazirani = "";
                                for (int z = 0; z < velicinaUnetog; z++) {
                                    bazirani += arrSplit[j].charAt(z);
                                }
                                if (bazirani.equalsIgnoreCase(autor)) {
                                    knjigeAutor.add(knjigeZaPrikaz.get(i));
                                }
                            }
                        }
                    }

                } else {  //SAMO JEDAN AUTOR

                    if (knjigeZaPrikaz.get(i).getAutor().equalsIgnoreCase(autor)) { //CEO AUTOR UNESEN
                        knjigeAutor.add(knjigeZaPrikaz.get(i));
                    } else { // DINAMICKO PRETRAZIVANJE
                        int velicinaUnetog = autor.length();
                        int velicinaBaza = knjigeZaPrikaz.get(i).getAutor().length();
                        if (velicinaBaza > velicinaUnetog) {
                            String bazirani = "";
                            for (int j = 0; j < velicinaUnetog; j++) {
                                bazirani += knjigeZaPrikaz.get(i).getAutor().charAt(j);
                            }
                            if (bazirani.equalsIgnoreCase(autor)) {
                                knjigeAutor.add(knjigeZaPrikaz.get(i));
                            }
                        }
                    }

                }
            }
        }

        if (knjigeAutor.size() == 0) {
            autorPoruka = "Ne postoje knjige traženog autora!";
            nemaA = true;
            pretragaAutor = false;
            return;
        }
        autorPoruka = "";
        nemaA = false;
        pretragaAutor = true;
        pretragaNaziv = false;
        pretragaZanr = false;
        autor = "";

    }

    private ArrayList<Knjiga> sveKnjige() {
        ArrayList<Knjiga> knjige = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Knjiga.class);
        knjige = (ArrayList<Knjiga>) c.list();

        session.getTransaction().commit();
        session.close();

        return knjige;

    }

    private ArrayList<Knjiga> sveKnjigePrikaz() {
        ArrayList<Knjiga> knjigePrikaz = new ArrayList<>();
        ArrayList<ZahtevKnjiga> knjigePrikazZahtev = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Knjiga.class);
        knjigePrikaz = (ArrayList<Knjiga>) c.list();

        Criteria cr = session.createCriteria(ZahtevKnjiga.class);
        knjigePrikazZahtev = (ArrayList<ZahtevKnjiga>) cr.list();

        session.getTransaction().commit();
        session.close();

        if (knjigePrikazZahtev.size() > 0) {
            for (int i = 0; i < knjigePrikazZahtev.size(); i++) {
                Knjiga k = new Knjiga();
                k.setAutor(knjigePrikazZahtev.get(i).getAutor());
                k.setDatum(knjigePrikazZahtev.get(i).getDatum());
                k.setDodata(false);
                k.setNaziv(knjigePrikazZahtev.get(i).getNaziv());
                if (knjigePrikazZahtev.get(i).getSlika() != null) {
                    k.setSlika(knjigePrikazZahtev.get(i).getSlika());
                }

                k.setZanr(knjigePrikazZahtev.get(i).getZanr());
                knjigePrikaz.add(k);

            }
        }

        return knjigePrikaz;

    }

    public boolean isNemaA() {
        return nemaA;
    }

    public void setNemaA(boolean nemaA) {
        this.nemaA = nemaA;
    }

    public boolean isNemaN() {
        return nemaN;
    }

    public void setNemaN(boolean nemaN) {
        this.nemaN = nemaN;
    }

    public void idiNaKnjige() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("knjige.xhtml");
    }

    public ArrayList<Knjiga> getKnjigeAutor() {
        return knjigeAutor;
    }

    public void setKnjigeAutor(ArrayList<Knjiga> knjigeAutor) {
        this.knjigeAutor = knjigeAutor;
    }

    public String getAutorPoruka() {
        return autorPoruka;
    }

    public void setAutorPoruka(String autorPoruka) {
        this.autorPoruka = autorPoruka;
    }

    public ArrayList<Knjiga> getKnjigeNaziv() {
        return knjigeNaziv;
    }

    public void setKnjigeNaziv(ArrayList<Knjiga> knjigeNaziv) {
        this.knjigeNaziv = knjigeNaziv;
    }

    public boolean isPretragaNaziv() {
        return pretragaNaziv;
    }

    public void setPretragaNaziv(boolean pretragaNaziv) {
        this.pretragaNaziv = pretragaNaziv;
    }

    public String getNazivPoruka() {
        return nazivPoruka;
    }

    public void setNazivPoruka(String nazivPoruka) {
        this.nazivPoruka = nazivPoruka;
    }

    public boolean isPretragaAutor() {
        return pretragaAutor;
    }

    public void setPretragaAutor(boolean pretragaAutor) {
        this.pretragaAutor = pretragaAutor;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Knjiga> getKnjige() {
        return knjige;
    }

    public void setKnjige(ArrayList<Knjiga> knjige) {
        this.knjige = knjige;
    }

    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        this.zanr = zanr;
    }

    public String getZanrPoruka() {
        return zanrPoruka;
    }

    public void setZanrPoruka(String zanrPoruka) {
        this.zanrPoruka = zanrPoruka;
    }

    public String getZanrKnjige() {
        return zanrKnjige;
    }

    public void setZanrKnjige(String zanrKnjige) {
        this.zanrKnjige = zanrKnjige;
    }

    public String getZanrKnjigePoruka() {
        return zanrKnjigePoruka;
    }

    public void setZanrKnjigePoruka(String zanrKnjigePoruka) {
        this.zanrKnjigePoruka = zanrKnjigePoruka;
    }

    public ArrayList<Zanr> getZanrovi() {
        return zanrovi;
    }

    public void setZanrovi(ArrayList<Zanr> zanrovi) {
        this.zanrovi = zanrovi;
    }

    public ArrayList<String> getNazivZanra() {
        return nazivZanra;
    }

    public void setNazivZanra(ArrayList<String> nazivZanra) {
        this.nazivZanra = nazivZanra;
    }

    public String getNemaZanrova() {
        return nemaZanrova;
    }

    public void setNemaZanrova(String nemaZanrova) {
        this.nemaZanrova = nemaZanrova;
    }

    public String getPostojiKnjigaSaZanrom() {
        return postojiKnjigaSaZanrom;
    }

    public void setPostojiKnjigaSaZanrom(String postojiKnjigaSaZanrom) {
        this.postojiKnjigaSaZanrom = postojiKnjigaSaZanrom;
    }

    public ArrayList<Knjiga> getKnjigeZanr() {
        return knjigeZanr;
    }

    public void setKnjigeZanr(ArrayList<Knjiga> knjigeZanr) {
        this.knjigeZanr = knjigeZanr;
    }

    public boolean isPretragaZanr() {
        return pretragaZanr;
    }

    public void setPretragaZanr(boolean pretragaZanr) {
        this.pretragaZanr = pretragaZanr;
    }

    public String getOznaceniZanr() {
        return oznaceniZanr;
    }

    public void setOznaceniZanr(String oznaceniZanr) {
        this.oznaceniZanr = oznaceniZanr;
    }

    public String getOznaceniZanrPoruka() {
        return oznaceniZanrPoruka;
    }

    public void setOznaceniZanrPoruka(String oznaceniZanrPoruka) {
        this.oznaceniZanrPoruka = oznaceniZanrPoruka;
    }

    public ArrayList<Knjiga> getKnjigeZaPrikaz() {
        return knjigeZaPrikaz;
    }

    public void setKnjigeZaPrikaz(ArrayList<Knjiga> knjigeZaPrikaz) {
        this.knjigeZaPrikaz = knjigeZaPrikaz;
    }

    //DODAVANJE 
    private String dodajAutor;
    private byte[] slika, bf;
    private String dodajZanr;
    private Date datum;
    private String dodajOpis;

    private String dodajNaziv;
    private ZahtevKnjiga knjiga = new ZahtevKnjiga();
    private String zanrZaBazu = "";
    private int brZanrova = 0;
    private String porukaDodavanje;
    private String autorZaBazu = "";
    private String porukaZaBrojZanrova = "";
    private String porukaZaDodatAutor = "";

    public void dodaj_knjigu() {
        if (autorZaBazu.equals("")) {
            porukaDodavanje = "Nije unet nijedan autor!";
            return;
        }
        if (zanrZaBazu.equals("")) {
            porukaDodavanje = "Nije unet nijedan žanr!";
            return;
        }

        knjiga.setAutor(autorZaBazu);
        knjiga.setDatum(datum);
        knjiga.setNaziv(dodajNaziv);
        knjiga.setZanr(zanrZaBazu);
        knjiga.setOpis(dodajOpis);

        //ubaci u listu knjiga ali oznaci da nije dodata
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        Transaction t = s.beginTransaction();

        s.save(knjiga);
        s.getTransaction().commit();
        s.close();

        zahteviKnjiga = zahtevi();
        autorZaBazu = "";
        datum = null;
        dodajNaziv = "";
        zanrZaBazu = "";
        dodajOpis = "";
        brAutora = 0;
        porukaZaBrojZanrova = "";
        porukaZaDodatAutor = "";
        knjigeZaPrikaz = sveKnjigePrikaz();
        porukaDodavanje = "Zahtev je poslat!";

    }

    private static int brAutora = 0;

    public void unesiAutora() {
        if (autorZaBazu.equals("")) {
            autorZaBazu += dodajAutor;

        } else {
            autorZaBazu += ",";
            autorZaBazu += dodajAutor;
        }
        dodajAutor = "";
        brAutora++;
        porukaZaDodatAutor = String.valueOf(brAutora) + ". autor uspešno dodat";

    }

    public void unesiZanr() {

        if (zanrZaBazu.equals(dodajZanr)) {
            porukaZaBrojZanrova = "Označeni žanr je već dodat!";
            return;
        }

        if (brZanrova < 3) {
            if (zanrZaBazu.contains(",")) {
                String[] arrSplit = zanrZaBazu.split(",");
                for (int i = 0; i < arrSplit.length; i++) {
                    if (arrSplit[i].equals(dodajZanr)) {

                        porukaZaBrojZanrova = "Označeni žanr je već dodat!";
                        return;

                    }
                }

            }

            if (zanrZaBazu.equals("")) {
                zanrZaBazu += dodajZanr;
            } else {
                zanrZaBazu += ",";
                zanrZaBazu += dodajZanr;
            }
            dodajZanr = "";
            brZanrova++;
            porukaZaBrojZanrova = String.valueOf(brZanrova) + ". žanr uspešno dodat!";
            if (brZanrova == 3) {
                porukaZaBrojZanrova = "Dodata su maksimalna 3 žanra!";

            }

        }
    }

    /**
     *
     * @param event
     */
    public void ucitajSliku(FileUploadEvent event) {
        UploadedFile file = event.getFile();

        if (file != null) {
            slika = file.getContent();
            knjiga.setSlika(slika);
            knjigaZaMenjanje.setSlika(slika);

        }
    }

    public String getDodajAutor() {
        return dodajAutor;
    }

    public void setDodajAutor(String dodajAutor) {
        this.dodajAutor = dodajAutor;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public byte[] getBf() {
        return bf;
    }

    public void setBf(byte[] bf) {
        this.bf = bf;
    }

    public String getDodajZanr() {
        return dodajZanr;
    }

    public void setDodajZanr(String dodajZanr) {
        this.dodajZanr = dodajZanr;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getDodajOpis() {
        return dodajOpis;
    }

    public void setDodajOpis(String dodajOpis) {
        this.dodajOpis = dodajOpis;
    }

    public String getDodajNaziv() {
        return dodajNaziv;
    }

    public void setDodajNaziv(String dodajNaziv) {
        this.dodajNaziv = dodajNaziv;
    }

    public ZahtevKnjiga getKnjiga() {
        return knjiga;
    }

    public void setKnjiga(ZahtevKnjiga knjiga) {
        this.knjiga = knjiga;
    }

    public String getZanrZaBazu() {
        return zanrZaBazu;
    }

    public void setZanrZaBazu(String zanrZaBazu) {
        this.zanrZaBazu = zanrZaBazu;
    }

    public int getBrZanrova() {
        return brZanrova;
    }

    public void setBrZanrova(int brZanrova) {
        this.brZanrova = brZanrova;
    }

    public String getPorukaDodavanje() {
        return porukaDodavanje;
    }

    public void setPorukaDodavanje(String porukaDodavanje) {
        this.porukaDodavanje = porukaDodavanje;
    }

    public String getAutorZaBazu() {
        return autorZaBazu;
    }

    public void setAutorZaBazu(String autorZaBazu) {
        this.autorZaBazu = autorZaBazu;
    }

    public String getPorukaZaBrojZanrova() {
        return porukaZaBrojZanrova;
    }

    public void setPorukaZaBrojZanrova(String porukaZaBrojZanrova) {
        this.porukaZaBrojZanrova = porukaZaBrojZanrova;
    }

    public String getPorukaZaDodatAutor() {
        return porukaZaDodatAutor;
    }

    public void setPorukaZaDodatAutor(String porukaZaDodatAutor) {
        this.porukaZaDodatAutor = porukaZaDodatAutor;
    }

    // PRIHVATANJE I ODBIJANJE ZAHTEVA
    private ArrayList<ZahtevKnjiga> zahtevi() {
        ArrayList<ZahtevKnjiga> zahtevi = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(ZahtevKnjiga.class);
        zahtevi = (ArrayList<ZahtevKnjiga>) c.list();
        session.getTransaction().commit();
        session.close();

        return zahtevi;
    }

    public void prihvati(int idzahtevknjiga) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(ZahtevKnjiga.class);
        ZahtevKnjiga z = (ZahtevKnjiga) c.add(Restrictions.eq("idzahtevknjiga", idzahtevknjiga)).uniqueResult();

        Knjiga k = new Knjiga();
        k.setAutor(z.getAutor());
        k.setDatum(z.getDatum());
        k.setNaziv(z.getNaziv());
        k.setOpis(z.getOpis());
        k.setSlika(z.getSlika());
        k.setZanr(z.getZanr());
        k.setDodata(true);

        knjige.add(k);

        session.save(k);

        t.commit();
        session.close();

        odbij(idzahtevknjiga);

    }

    public void odbij(int idzahtevknjiga) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(ZahtevKnjiga.class);
        ZahtevKnjiga z = (ZahtevKnjiga) c.add(Restrictions.eq("idzahtevknjiga", idzahtevknjiga)).uniqueResult();
        session.delete(z);

        for (int i = 0; i < zahteviKnjiga.size(); i++) {
            if (zahteviKnjiga.get(i).getIdzahtevknjiga() == z.getIdzahtevknjiga()) {
                zahteviKnjiga.remove(i);
            }
        }

        session.flush();
        t.commit();
        session.close();
        knjigeZaPrikaz = sveKnjigePrikaz();

    }

    public static int getBrAutora() {
        return brAutora;
    }

    public static void setBrAutora(int brAutora) {
        knjigaController.brAutora = brAutora;
    }

    public ArrayList<ZahtevKnjiga> getZahteviKnjiga() {
        return zahteviKnjiga;
    }

    public void setZahteviKnjiga(ArrayList<ZahtevKnjiga> zahteviKnjiga) {
        this.zahteviKnjiga = zahteviKnjiga;
    }

    // MENJANJE KNJIGE
    private boolean prikaz = false;
    private Knjiga knjigaZaMenjanje = new Knjiga();
    private String menjajNaziv;
    private String menjajOpis;
    private String menjajAutor;
    private String menjajAutorBaza = "";
    private String menjajZanr;
    private String menjajZanrBaza = "";
    private byte[] menjajSlika;
    private Date menjajDatum;
    private String poruka1 = "", poruka2 = "", poruka3 = "", poruka4 = "", poruka5 = "", poruka6 = "";
    private int brAutoraMenjaj = 1, brZanrovaMenjaj = 0;

    public void ucitajSlikuMenjaj(FileUploadEvent event) {
        UploadedFile file = event.getFile();

        if (file != null) {
            menjajSlika = file.getContent();
            knjigaZaMenjanje.setSlika(menjajSlika);

        }
    }

    public void unesiZanrMenjaj() {
        if (brZanrovaMenjaj > 3) {
            poruka5 = "Dodata su maksimalna 3 žanra!";
            return;
        }

        if (menjajZanrBaza.equals(menjajZanr)) {
            poruka5 = "Označeni žanr je već dodat!";
            return;
        }

        if (brZanrovaMenjaj < 4) {
            if (menjajZanrBaza.contains(",")) {
                String[] arrSplit = menjajZanrBaza.split(",");
                for (int i = 0; i < arrSplit.length; i++) {
                    if (arrSplit[i].equals(menjajZanr)) {

                        poruka5 = "Označeni žanr je već dodat!";
                        return;

                    }
                }

            }

            if (menjajZanrBaza.equals("")) {
                menjajZanrBaza += menjajZanr;
            } else {
                menjajZanrBaza += ",";
                menjajZanrBaza += menjajZanr;
            }
            menjajZanr = "";

            poruka5 = String.valueOf(brZanrovaMenjaj) + ". žanr uspešno dodat!";

            brZanrovaMenjaj++;

        }
    }

    public void unesiAutoraMenjanje() {
        if (menjajAutorBaza.equals("")) {
            menjajAutorBaza += menjajAutor;

        } else {
            menjajAutorBaza += ",";
            menjajAutorBaza += menjajAutor;
        }
        menjajAutor = "";

        poruka4 = "Unesen je " + String.valueOf(brAutoraMenjaj) + ". autor. Možete promeniti autora";

        brAutoraMenjaj++;

    }

    public void promeniSliku() {
        if (menjajSlika == null) {
            poruka6 = "Nije dodata nijedna slika! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", knjigaZaMenjanje.getIdknjiga())).uniqueResult();
        baseKnjiga.setSlika(menjajSlika);

        s.save(baseKnjiga);
        s.getTransaction().commit();
        s.close();
        knjige = sveKnjige();
        poruka6 = "Slika uspešno promenjena!";

    }

    public void promeniAutora() {
        if (menjajAutorBaza.equals("")) {
            poruka4 = "Niste uneli nijednog autora!";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        knjigaZaMenjanje.setAutor(menjajAutorBaza);
        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", knjigaZaMenjanje.getIdknjiga())).uniqueResult();
        baseKnjiga.setAutor(menjajAutorBaza);

        s.save(baseKnjiga);
        s.getTransaction().commit();
        s.close();
        knjige = sveKnjige();
        poruka4 = "Autor je promenjen";
        brAutoraMenjaj = 1;
        menjajAutorBaza = "";

    }

    public void promeniZanr() {
        if (menjajZanrBaza.equals("")) {
            poruka5 = "Niste uneli nijedan žanr!";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        knjigaZaMenjanje.setZanr(menjajZanrBaza);
        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", knjigaZaMenjanje.getIdknjiga())).uniqueResult();
        baseKnjiga.setZanr(menjajZanrBaza);

        s.save(baseKnjiga);
        s.getTransaction().commit();
        s.close();
        knjige = sveKnjige();
        poruka5 = "Žanr je promenjen";
        brZanrovaMenjaj = 1;
        menjajZanrBaza = "";

    }

    public void promeniDatum() {
        if (menjajDatum == null) {
            poruka3 = "Uneti novi datum!";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        knjigaZaMenjanje.setDatum(menjajDatum);
        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", knjigaZaMenjanje.getIdknjiga())).uniqueResult();
        baseKnjiga.setDatum(menjajDatum);

        s.save(baseKnjiga);
        s.getTransaction().commit();
        s.close();
        knjige = sveKnjige();
        poruka3 = "Datum je promenjen";

    }

    public void promeniNaziv() {
        if (menjajNaziv.equals("")) {
            poruka1 = "Uneti novi naziv!";
            return;
        }

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        knjigaZaMenjanje.setNaziv(menjajNaziv);
        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", knjigaZaMenjanje.getIdknjiga())).uniqueResult();
        baseKnjiga.setNaziv(menjajNaziv);

        s.save(baseKnjiga);
        s.getTransaction().commit();
        s.close();
        knjige = sveKnjige();
        poruka1 = "Naziv je promenjen";

    }

    public void promeniOpis() {
        if (menjajOpis.equals("")) {
            poruka2 = "Uneti novi opis!";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        knjigaZaMenjanje.setOpis(menjajOpis);
        Criteria cr = s.createCriteria(Knjiga.class);
        Knjiga baseKnjiga = (Knjiga) cr.add(Restrictions.eq("idknjiga", knjigaZaMenjanje.getIdknjiga())).uniqueResult();
        baseKnjiga.setOpis(menjajOpis);

        s.save(baseKnjiga);
        s.getTransaction().commit();
        s.close();
        knjige = sveKnjige();
        poruka2 = "Opis je promenjen";

    }

    public void promeni(int idKnjige) {
        poruka1 = "";
        poruka2 = "";
        poruka3 = "";
        poruka4 = "";
        poruka5 = "";
        poruka6 = "";
        brAutoraMenjaj = 1;
        brZanrovaMenjaj = 1;
        prikaz = true;

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria c = s.createCriteria(Knjiga.class);

        knjigaZaMenjanje = (Knjiga) c.add(Restrictions.eq("idknjiga", idKnjige)).uniqueResult();
        s.getTransaction().commit();
        s.close();

    }
    public void nazad(String tip) throws IOException {
        poruka1 = "";
        poruka2 = "";
        poruka3 = "";
        poruka4 = "";
        poruka5 = "";
        poruka6 = "";
        pretragaAutor = false;
        pretragaNaziv = false;
        pretragaZanr = false;
        autor = "";
        zanr = "";
        naziv = "";
        autorPoruka = "";
        zanrPoruka = "";
        nazivPoruka = "";
        prikaz = false;
        postojiKnjigaSaZanrom = "";
        zanrKnjige = "";
        zanrKnjigePoruka = "";
        zanrZaBazu = "";
        nemaZanrova = "";
        porukaDodavanje = "";
        porukaZaBrojZanrova = "";
        porukaZaDodatAutor = "";
          datum = null;
        dodajAutor = "";
        dodajNaziv = "";
        dodajOpis= "";
        dodajZanr ="";
        nemaA = false;
        nemaN = false;
        
        
        
        if(tip.equals("administrator")) {
        FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml"); }
        else  if(tip.equals("moderator")) {
         FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml"); }
        else {
             FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");
        }
        
        

    }

    public void nazadGost() throws IOException {
        poruka1 = "";
        poruka2 = "";
        poruka3 = "";
        poruka4 = "";
        poruka5 = "";
        poruka6 = "";
        pretragaAutor = false;
        pretragaNaziv = false;
        pretragaZanr = false;
        autor = "";
        zanr = "";
        naziv = "";
        autorPoruka = "";
        zanrPoruka = "";
        nazivPoruka = "";
         prikaz = false;
           postojiKnjigaSaZanrom = "";
        zanrKnjige = "";
        zanrKnjigePoruka = "";
        zanrZaBazu = "";
        nemaZanrova = "";
          porukaDodavanje = "";
        porukaZaBrojZanrova = "";
        porukaZaDodatAutor = "";
          datum = null;
        dodajAutor = "";
        dodajNaziv = "";
        dodajOpis= "";
        dodajZanr ="";
           nemaA = false;
        nemaN = false;
        

        FacesContext.getCurrentInstance().getExternalContext().redirect("gost.xhtml");

    }
    public void nazadGost2() throws IOException {
     poruka1 = "";
        poruka2 = "";
        poruka3 = "";
        poruka4 = "";
        poruka5 = "";
        poruka6 = "";
        pretragaAutor = false;
        pretragaNaziv = false;
        pretragaZanr = false;
        autor = "";
        zanr = "";
        naziv = "";
        autorPoruka = "";
        zanrPoruka = "";
        nazivPoruka = "";
         prikaz = false;
           postojiKnjigaSaZanrom = "";
        zanrKnjige = "";
        zanrKnjigePoruka = "";
        zanrZaBazu = "";
        nemaZanrova = "";
          porukaDodavanje = "";
        porukaZaBrojZanrova = "";
        porukaZaDodatAutor = "";
        datum = null;
        dodajAutor = "";
        dodajNaziv = "";
        dodajOpis= "";
        dodajZanr ="";
           nemaA = false;
        nemaN = false;
        
                


        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

    }

    
    public boolean isPrikaz() {
        return prikaz;
    }

    public void setPrikaz(boolean prikaz) {
        this.prikaz = prikaz;
    }

    public Knjiga getKnjigaZaMenjanje() {
        return knjigaZaMenjanje;
    }

    public void setKnjigaZaMenjanje(Knjiga knjigaZaMenjanje) {
        this.knjigaZaMenjanje = knjigaZaMenjanje;
    }

    public String getMenjajNaziv() {
        return menjajNaziv;
    }

    public void setMenjajNaziv(String menjajNaziv) {
        this.menjajNaziv = menjajNaziv;
    }

    public String getMenjajOpis() {
        return menjajOpis;
    }

    public void setMenjajOpis(String menjajOpis) {
        this.menjajOpis = menjajOpis;
    }

    public String getPoruka1() {
        return poruka1;
    }

    public void setPoruka1(String poruka1) {
        this.poruka1 = poruka1;
    }

    public String getPoruka2() {
        return poruka2;
    }

    public void setPoruka2(String poruka2) {
        this.poruka2 = poruka2;
    }

    public Date getMenjajDatum() {
        return menjajDatum;
    }

    public void setMenjajDatum(Date menjajDatum) {
        this.menjajDatum = menjajDatum;
    }

    public String getPoruka3() {
        return poruka3;
    }

    public void setPoruka3(String poruka3) {
        this.poruka3 = poruka3;
    }

    public String getMenjajAutor() {
        return menjajAutor;
    }

    public void setMenjajAutor(String menjajAutor) {
        this.menjajAutor = menjajAutor;
    }

    public String getMenjajAutorBaza() {
        return menjajAutorBaza;
    }

    public void setMenjajAutorBaza(String menjajAutorBaza) {
        this.menjajAutorBaza = menjajAutorBaza;
    }

    public String getPoruka4() {
        return poruka4;
    }

    public void setPoruka4(String poruka4) {
        this.poruka4 = poruka4;
    }

    public int getBrAutoraMenjaj() {
        return brAutoraMenjaj;
    }

    public void setBrAutoraMenjaj(int brAutoraMenjaj) {
        this.brAutoraMenjaj = brAutoraMenjaj;
    }

    public String getMenjajZanr() {
        return menjajZanr;
    }

    public void setMenjajZanr(String menjajZanr) {
        this.menjajZanr = menjajZanr;
    }

    public String getMenjajZanrBaza() {
        return menjajZanrBaza;
    }

    public void setMenjajZanrBaza(String menjajZanrBaza) {
        this.menjajZanrBaza = menjajZanrBaza;
    }

    public String getPoruka5() {
        return poruka5;
    }

    public void setPoruka5(String poruka5) {
        this.poruka5 = poruka5;
    }

    public int getBrZanrovaMenjaj() {
        return brZanrovaMenjaj;
    }

    public void setBrZanrovaMenjaj(int brZanrovaMenjaj) {
        this.brZanrovaMenjaj = brZanrovaMenjaj;
    }

    public byte[] getMenjajSlika() {
        return menjajSlika;
    }

    public void setMenjajSlika(byte[] menjajSlika) {
        this.menjajSlika = menjajSlika;
    }

    public String getPoruka6() {
        return poruka6;
    }

    public void setPoruka6(String poruka6) {
        this.poruka6 = poruka6;
    }

}
