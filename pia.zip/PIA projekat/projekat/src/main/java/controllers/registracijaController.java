/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.User;
import entities.Zahtev;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class registracijaController {

    private String ime;
    private String prezime;
    private String username;
    private String password;
    private String confirm_password;
    private Zahtev zahtev = new Zahtev();
    private String grad;
    private String email;
    private String tip;
    private Date datum;
    private byte[] slika, bf;
    private String poruka;
    private String drzava;

    public String getDrzava() {
        return drzava;
    }

    public void setDrzava(String drzava) {
        this.drzava = drzava;
    }
    

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    public String getConfirm_password() {
        return confirm_password;
    }

    public Zahtev getZahtev() {
        return zahtev;
    }

    public void setZahtev(Zahtev zahtev) {
        this.zahtev = zahtev;
    }

    public byte[] getBf() {
        return bf;
    }

    public void setBf(byte[] bf) {
        this.bf = bf;
    }

    public void setConfirm_password(String confirm_password) {
        this.confirm_password = confirm_password;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public void ucitajSliku(FileUploadEvent event) {
        UploadedFile file = event.getFile();

        if (file != null) {
            slika = file.getContent();
            zahtev.setSlika(slika);


        } 
    }
    

    public static boolean proveri_username(String username) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);

        User user1 = (User) cr.add(Restrictions.eq("username", username)).uniqueResult();

        if (user1 != null) {

            username = "";
            return false;
        }
        return true;
    }

    public static boolean proveri_email(String email) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr2 = s.createCriteria(User.class);
        User user2 = (User) cr2.add(Restrictions.eq("email", email)).uniqueResult();
        if (user2 != null) {

            email = "";
            return false;
        } else {
            return true;
        }
    }
    
     public String submit_form(){
         try {
        String gRecaptchaResponse = FacesContext.getCurrentInstance().
        getExternalContext().getRequestParameterMap().get("g-recaptcha-response");
        boolean verify = VerifyRecaptcha.verify(gRecaptchaResponse);
        if(verify){
             return "Success";
        }else{
             FacesContext context = FacesContext.getCurrentInstance();
             context.addMessage( null, new FacesMessage( "Select Captcha") );
             return "";
          }
         } catch (Exception e) {
             System.out.println(e);
         }
        return "";
     }    
      

    public void posaljiZahvtevZaRegistraciju() throws IOException {
        
//        if("".equals(submit_form())) {
//             poruka = "Verifikuj Captcha!";
//            return;
//        }


        if (!proveri_username(username)) {
            poruka = "Korisnik sa unetim korisničkim imenom već postoji. Pokušati ponovo!";
            return;
        }
        if (!proveri_email(email)) {
            poruka = "Korisnik sa unetim e-mailom već postoji. Pokušati ponovo!";
            return;
        }

        
        zahtev.setIme(ime);
        zahtev.setPassword(password);
        zahtev.setDatum(datum);
        zahtev.setGrad(grad);
        zahtev.setPrezime(prezime);
        zahtev.setTip(tip);
        zahtev.setUsername(username);
        zahtev.setEmail(email);
        zahtev.setDrzava(drzava);
        

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        Transaction t = s.beginTransaction();

        s.save(zahtev);
        s.getTransaction().commit();
        s.close();

        drzava = "";
        ime = "";
        password = "";
        confirm_password = "";
        datum = null;
        grad = "";
        prezime = "";
        tip = "";
        username = "";
        slika = null;
        email = null;
        poruka = "";

        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

    }

}
