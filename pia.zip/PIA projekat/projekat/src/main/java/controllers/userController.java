/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Knjiga;
import entities.Komentar;
import entities.ListaCitanje;
import entities.Obavestenje;
import entities.Pracenje;
import entities.ProcitaneKnjige;
import entities.TrenutnoCita;
import entities.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.pie.PieChartDataSet;
import org.primefaces.model.charts.pie.PieChartModel;


import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class userController {

    private PieChartModel pieChartModel = new PieChartModel();

    private User user = new User();
    ArrayList<Knjiga> procitaneKnjige = new ArrayList<>();
    ArrayList<Knjiga> trenutnoCita = new ArrayList<>();
    ArrayList<Knjiga> listaCitanje = new ArrayList<>();
    ArrayList<String> zanrovi = new ArrayList<>();
    ArrayList<Obavestenje> obevestenja= new ArrayList<>();
    ArrayList<Komentar> komentari = new ArrayList<>();

    private String poruka = "";
    private int brojStrana = 100, brojProcitanih = 0, brojStrana1 = 100, brojProcitanih1 = 0;
    private String barPoruka = "";
    private double procenat = 0;
    private String komentar = "";
    private int ocena;
    private String porukaKomentar;
    private String pracenjePoruka = "";
    
    private ArrayList<Obavestenje> svaObavestenja() {
        ArrayList<Obavestenje> obavestenja = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Obavestenje.class);
        obavestenja = (ArrayList<Obavestenje>) c.add(Restrictions.eq("iduser", user.getIdUser())).list();

        session.getTransaction().commit();
        session.close();

        return obavestenja;

    }

   
    
    public void zapratiKorisnika(int idpratilac, int idpracen) {
           SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Pracenje.class);
          ArrayList<Pracenje> pracenja = (ArrayList<Pracenje>) cr.add(Restrictions.eq("idpratilac",idpratilac )).list();
          
          for(int i = 0 ;i < pracenja.size(); i++) {
              if(pracenja.get(i).getIdpracen() == idpracen) {
                  pracenjePoruka = "Korisnik je već zapraćen!";
                  return;
              }
          }
          
          Pracenje pr = new Pracenje();
          pr.setIdpracen(idpracen);
          pr.setIdpratilac(idpratilac);
          
          pracenjePoruka = "Zapratili ste korisnika " + user.getUsername();
              s.save(pr);
                s.getTransaction().commit();
                s.close();
          
          
        
        
        
    }
    
    
    

    public void komentarisi(int idKnjiga, int idUser, String username) {
        user.setUsername(username);
        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();

        //VISE OD 1000 RECI
        if(!komentar.equals("")) {
        String[] arrSplit = komentar.split(" ");
         if (arrSplit.length > 1000) {
            porukaKomentar = "Komentar ne sme da ima više od 1000 reči!";
            return;
        }
        }
       
        if(ocena == 0) {
            porukaKomentar = "Unos ocene je obavezan, komentar nije obavezan!";
            return;
        }

        //korisnik je vec komentarisao , azuriraj
        for (int i = 0; i < komentari.size(); i++) {
            if (komentari.get(i).getIdknjiga() == idKnjiga) {
                SessionFactory sf = HibernateUtil.getSessionFactory();
                Session s = sf.openSession();
                s.beginTransaction();

                Criteria cr = s.createCriteria(Komentar.class);

                // promeni prosecnu ocenu
                ArrayList<Komentar> sviKomentari = (ArrayList<Komentar>) cr.add(Restrictions.eq("idknjiga", idKnjiga)).list();
                int zbirSvihOcena = 0;
                for (int j = 0; j < sviKomentari.size(); j++) {
                    if (sviKomentari.get(j).getUsername().equals(komentari.get(i).getUsername())) {
                        zbirSvihOcena += ocena; //ubaci novu ocenu korisnija
                    } else {
                        zbirSvihOcena += sviKomentari.get(j).getOcena();
                    }
                }

                int velicina = sviKomentari.size();
                float prosek = (float) (zbirSvihOcena) / ((float) velicina);

                //nadji knjigu i promeni prosecnu ocenu
                if(!komentar.equals("")) {
                komentari.get(i).setKomentar(komentar);
                }
                komentari.get(i).setOcena(ocena);
                Criteria cri = s.createCriteria(Komentar.class);
                Komentar kom = (Komentar) cri.add(Restrictions.eq("idkomentar", komentari.get(i).getIdkomentar())).uniqueResult();
                 komentari.remove(kom);
                if(!komentar.equals("")) {
                kom.setKomentar(komentar);
                }
                kom.setOcena(ocena);
                    Criteria c = s.createCriteria(Knjiga.class);
                   Knjiga k = (Knjiga) c.add(Restrictions.eq("idknjiga", idKnjiga)).uniqueResult();
                k.setOcena(prosek);
               
                //salji svim pratiocima da si komentarisao
                Criteria crit = s.createCriteria(Pracenje.class);
                ArrayList<Pracenje> pracenja = new ArrayList<>();
                pracenja = (ArrayList<Pracenje>) crit.add(Restrictions.eq("idpracen", user.getIdUser())).list();
                String obavestenje = "Korisnik " + user.getUsername() + " je kometarisao knjigu " + k.getNaziv();
                for(int j = 0 ; j < pracenja.size(); j++) {
                     Obavestenje o = new Obavestenje();
                      Session ss = sf.openSession();
                      ss.beginTransaction();
                    o.setIduser(pracenja.get(j).getIdpratilac());
                    o.setObavestenje(obavestenje);
                    ss.save(o);
                    ss.getTransaction().commit();
                    ss.clear();
                }
           
                s.save(k);
                s.save(kom);
                s.getTransaction().commit();
                s.close();
                  komentari = komentari1();
                porukaKomentar = "Usprešno promenjen komentar!";

                return;
            }
        }

        //korisnik nije komentarisao
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Komentar.class);

        // promeni prosecnu ocenu
        ArrayList<Komentar> sviKomentari = (ArrayList<Komentar>) cr.add(Restrictions.eq("idknjiga", idKnjiga)).list();
        int zbirSvihOcena = 0;
        for (int j = 0; j < sviKomentari.size(); j++) {
            zbirSvihOcena += sviKomentari.get(j).getOcena();
        }
        zbirSvihOcena += ocena;
        int velicina = sviKomentari.size() + 1;
        float prosek = (float) (zbirSvihOcena) / ((float) velicina);

        Komentar kom = new Komentar();
        kom.setIdknjiga(idKnjiga);
        kom.setKomentar(komentar);
        kom.setOcena(ocena);
        kom.setUsername(username);
         //nadji knjigu i promeni prosecnu ocenu
        Criteria c = s.createCriteria(Knjiga.class);

        // promeni prosecnu ocenu
        Knjiga k = (Knjiga) c.add(Restrictions.eq("idknjiga", idKnjiga)).uniqueResult();
        k.setOcena(prosek);
        s.save(k);
        
         Criteria crit = s.createCriteria(Pracenje.class);
                ArrayList<Pracenje> pracenja = new ArrayList<>();
                pracenja = (ArrayList<Pracenje>) crit.add(Restrictions.eq("idpracen", user.getIdUser())).list();
                String obavestenje = "Korisnik " + user.getUsername() + " je kometarisao knjigu " + " " + k.getNaziv();
                 
                for(int j = 0 ; j < pracenja.size(); j++) {
                      Obavestenje o = new Obavestenje();
                      Session ss = sf.openSession();
                         ss.beginTransaction();
                    o.setIduser(pracenja.get(j).getIdpratilac());
                    o.setObavestenje(obavestenje);
                    ss.save(o);
                    ss.getTransaction().commit();
                    ss.clear();
                    
                }

        s.save(kom);
        s.getTransaction().commit();
        s.close();
         porukaKomentar = "Usprešno poslat komentar!";

     
    }

    public boolean mozeKomentarProcitao50() {
        //procitao 50%
        if (procenat >= 50) {
            return true;
        } else {
            return false;
        }
    }

    //procitao celu knjigu
    public boolean procitaoKnjigu(int idKnjiga, int idUser) {
        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();

        int z = 0;
        for (int i = 0; i < procitaneKnjige.size(); i++) {
            if (procitaneKnjige.get(i).getIdknjiga() == idKnjiga) {
                return true;
            }
        }

        return false;

    }

    public void ubaciPodatke(int idKnjiga, int idUser) {

        if (brojProcitanih1 > brojStrana1) {
            barPoruka = "Broj pročitanih strana ne može biti veći od broja strana knjige!";
            return;

        }

        setBrojStrana(brojStrana1);
        setBrojProcitanih(brojProcitanih1);
        procenat = (double) ((double) brojProcitanih / (double) brojStrana1) * 100.;

        barPoruka = "";

        if (brojProcitanih == brojStrana) {
            barPoruka = "Knjiga je pročitana!";
        }

        if (brojProcitanih == brojStrana) {
            barPoruka = "Knjiga je pročitana!";
            procitao(idKnjiga, idUser);
            procenat = 0;
            brojProcitanih1 = 0;
            brojStrana1 = 0;

        }

    }

    public boolean trenutnoSeCitaKnjiga(int idKnjiga, int idUser) {
        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();
        int p = 0;
        for (int i = 0; i < trenutnoCita.size(); i++) {
            if (trenutnoCita.get(i).getIdknjiga() == idKnjiga) {
                p++;
            }
        }
        if (p == 0) {
            return false;
        } else {
            return true;
        }

    }

    public void ukloniSaListe(int idKnjiga, int idUser) {

        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();

        int z = 0;
        for (int i = 0; i < listaCitanje.size(); i++) {
            if (listaCitanje.get(i).getIdknjiga() == idKnjiga) {
                z++;
            }
        }
        if (z == 0) {
            poruka = "Knjiga nije na listi za čitanje!";
            return;
        }

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(ListaCitanje.class);
        ArrayList<ListaCitanje> l = (ArrayList<ListaCitanje>) c.add(Restrictions.eq("idknjiga", idKnjiga)).list();

        ListaCitanje ll = new ListaCitanje();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).getIduser() == idUser) {
                ll = l.get(i);
            }
        }

        poruka = "Knjiga uspešno obrisana sa liste!";
        session.delete(ll);

        for (int i = 0; i < listaCitanje.size(); i++) {
            if (listaCitanje.get(i).getIdknjiga() == idKnjiga) {
                listaCitanje.remove(i);
            }
        }

        session.flush();
        t.commit();
        session.close();

    }

    public void trenutnoSeCita(int idKnjiga, int idUser) {
        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(TrenutnoCita.class);
        ArrayList<TrenutnoCita> pk = (ArrayList<TrenutnoCita>) c.add(Restrictions.eq("idknjiga", idKnjiga)).list();

        //vec je na listi citanja
        for (int i = 0; i < pk.size(); i++) {
            if (pk.get(i).getIduser() == idUser) {
                poruka = "Knjiga se već trenutno čita!";
                return;
            }
        }

        for (int i = 0; i < procitaneKnjige.size(); i++) {
            if (procitaneKnjige.get(i).getIdknjiga() == idKnjiga) {
                poruka = "Knjiga je pročitana!";
                return;
            }
        }

        //ukloni sa liste ako se trenutno cita
        for (int i = 0; i < listaCitanje.size(); i++) {
            if (listaCitanje.get(i).getIdknjiga() == idKnjiga) {
                ukloniSaListeZaCitanje(idKnjiga, idUser);
            }
        }

        poruka = "Stavljeno na listu za čitanje!";

        TrenutnoCita lc = new TrenutnoCita();
        lc.setIdknjiga(idKnjiga);
        lc.setIduser(idUser);

        session.save(lc);

        t.commit();
        session.close();

    }

    public void staviNaListu(int idKnjiga, int idUser) {
        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(ListaCitanje.class);
        ArrayList<ListaCitanje> pk = (ArrayList<ListaCitanje>) c.add(Restrictions.eq("idknjiga", idKnjiga)).list();

        //vec je na listi citanja
        for (int i = 0; i < pk.size(); i++) {
            if (pk.get(i).getIduser() == idUser) {
                poruka = "Knjiga je već na listi za citanje!";
                return;
            }
        }

        for (int i = 0; i < procitaneKnjige.size(); i++) {
            if (procitaneKnjige.get(i).getIdknjiga() == idKnjiga) {
                poruka = "Knjiga je pročitana!";
                return;
            }
        }

        for (int i = 0; i < trenutnoCita.size(); i++) {
            if (trenutnoCita.get(i).getIdknjiga() == idKnjiga) {
                poruka = "Knjiga se trenutno čita!";
                return;
            }
        }

        poruka = "Stavljeno na listu za čitanje!";

        ListaCitanje lc = new ListaCitanje();
        lc.setIdknjiga(idKnjiga);
        lc.setIduser(idUser);

        session.save(lc);

        t.commit();
        session.close();

    }

    public void procitao(int idKnjiga, int idUser) {

        user.setIdUser(idUser);
        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(ProcitaneKnjige.class);
        ArrayList<ProcitaneKnjige> pk = (ArrayList< ProcitaneKnjige>) c.add(Restrictions.eq("idknjiga", idKnjiga)).list();

        //vec je stavljeno da je procitao
        for (int i = 0; i < pk.size(); i++) {
            if (pk.get(i).getIduser() == idUser) {
                poruka = "Knjiga je vec procitana!";
                return;
            }
        }

        //izbrisi je sa trenutno cita
        for (int i = 0; i < trenutnoCita.size(); i++) {
            if (trenutnoCita.get(i).getIdknjiga() == idKnjiga) {
                ukloniSaTrenutnoCita(idKnjiga, idUser);
            }
        }

        //ukloni sa liste za citanje
        for (int i = 0; i < listaCitanje.size(); i++) {
            if (listaCitanje.get(i).getIdknjiga() == idKnjiga) {
                ukloniSaListeZaCitanje(idKnjiga, idUser);
            }
        }

        poruka = "Pročitano!";

        ProcitaneKnjige pkk = new ProcitaneKnjige();
        pkk.setIdknjiga(idKnjiga);
        pkk.setIduser(idUser);

        session.save(pkk);

        t.commit();
        session.close();

    }

    private ArrayList<Komentar> komentari1() {
        ArrayList<Komentar> kom = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Komentar.class);
        kom = (ArrayList<Komentar>) c.add(Restrictions.eq("username", user.getUsername())).list();

        session.getTransaction().commit();
        session.close();

        return kom;

    }

    public Knjiga komentarisanaKnjiga(int id) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Knjiga.class);
        Knjiga k = (Knjiga) c.add(Restrictions.eq("idknjiga", id)).uniqueResult();

        session.getTransaction().commit();
        session.close();

        return k;

    }

    public void ukloniSaListeZaCitanje(int idKnjiga, int idUser) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(ListaCitanje.class);
        ArrayList<ListaCitanje> l = (ArrayList<ListaCitanje>) c.add(Restrictions.eq("idknjiga", idKnjiga)).list();

        ListaCitanje ll = new ListaCitanje();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).getIduser() == idUser) {
                ll = l.get(i);
            }
        }

        session.delete(ll);

        for (int i = 0; i < listaCitanje.size(); i++) {
            if (listaCitanje.get(i).getIdknjiga() == idKnjiga) {
                listaCitanje.remove(i);
            }
        }

        session.flush();
        t.commit();
        session.close();

    }

    public void ukloniSaTrenutnoCita(int idKnjiga, int idUser) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(TrenutnoCita.class);
        ArrayList<TrenutnoCita> l = (ArrayList<TrenutnoCita>) c.add(Restrictions.eq("idknjiga", idKnjiga)).list();

        TrenutnoCita ll = new TrenutnoCita();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).getIduser() == idUser) {
                ll = l.get(i);
            }
        }

        session.delete(ll);

        for (int i = 0; i < trenutnoCita.size(); i++) {
            if (trenutnoCita.get(i).getIdknjiga() == idKnjiga) {
                trenutnoCita.remove(i);
            }
        }

        session.flush();
        t.commit();
        session.close();

    }

    private ArrayList<Knjiga> procitane() {
        ArrayList<ProcitaneKnjige> pr = new ArrayList<>();
        ArrayList<Knjiga> sveKnjige = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(ProcitaneKnjige.class);
        pr = (ArrayList<ProcitaneKnjige>) c.add(Restrictions.eq("iduser", user.getIdUser())).list();

        Criteria cr = session.createCriteria(Knjiga.class);
        sveKnjige = (ArrayList<Knjiga>) cr.list();

        session.getTransaction().commit();
        session.close();

        ArrayList<Knjiga> procitane = new ArrayList<>();

        for (int i = 0; i < pr.size(); i++) {
            for (int j = 0; j < sveKnjige.size(); j++) {
                if (pr.get(i).getIdknjiga() == sveKnjige.get(j).getIdknjiga()) {
                    procitane.add(sveKnjige.get(j));
                }
            }
        }

        //SVI ZANROVI KOJE JE PROCITAO
        for (int i = 0; i < procitane.size(); i++) {
            if (procitane.get(i).getZanr().contains(",")) { //knjiga ima vise zanrova
                String[] arrSplit = procitane.get(i).getZanr().split(",");
                for (int j = 0; j < arrSplit.length; j++) {
                    if (!zanrovi.contains(arrSplit[j])) {
                        zanrovi.add(arrSplit[j]);
                    }

                }

            } else { //knjiga ima 1 zanr
                //vec postoji u nizu
                if (!zanrovi.contains(procitane.get(i).getZanr())) {
                    zanrovi.add(procitane.get(i).getZanr());
                }
            }
        }

        double[] procenat = new double[zanrovi.size()];
        double vrednostJedneKnjige = (double) ((1.0) / (procitane.size())) * 100;
        for (int i = 0; i < zanrovi.size(); i++) {
            for (int j = 0; j < procitane.size(); j++) {

                if (procitane.get(j).getZanr().contains(",")) {
                    String[] arrSplit = procitane.get(j).getZanr().split(",");

                    for (int p = 0; p < arrSplit.length; p++) {
                        if (arrSplit[p].equals(zanrovi.get(i))) {
                            procenat[i] += (vrednostJedneKnjige) / ((double) arrSplit.length);

                        }
                    }
                } else {
                    if (zanrovi.get(i).equals(procitane.get(j).getZanr())) {
                        procenat[i] += vrednostJedneKnjige;
                    }
                }
            }
        }

        //REALIZACIJA PIE CHARTA
        pieChartModel = new PieChartModel();
        ChartData data = new ChartData();

        PieChartDataSet dataSet = new PieChartDataSet();
        List<Number> values = new ArrayList<>();
        for (int i = 0; i < procenat.length; i++) {
            values.add(procenat[i]);
        }

        dataSet.setData(values);

        List<String> bgColors = new ArrayList<>();
        for (int i = 0; i < procenat.length; i++) { //random boje
            int r = (int) (Math.random() * 255);
            int g = (int) (Math.random() * 255);
            int b = (int) (Math.random() * 255);

            bgColors.add("rgb(" + r + ", " + g + ", " + b + ")");

        }

        dataSet.setBackgroundColor(bgColors);

        data.addChartDataSet(dataSet);
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < zanrovi.size(); i++) {
            labels.add(zanrovi.get(i));
        }

        data.setLabels(labels);

        pieChartModel.setData(data);

        return procitane;

    }

    private ArrayList<Knjiga> trenutno() {
        ArrayList<TrenutnoCita> pr = new ArrayList<>();
        ArrayList<Knjiga> sveKnjige = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(TrenutnoCita.class);
        pr = (ArrayList<TrenutnoCita>) c.add(Restrictions.eq("iduser", user.getIdUser())).list();
        Criteria cr = session.createCriteria(Knjiga.class);
        sveKnjige = (ArrayList<Knjiga>) cr.list();

        session.getTransaction().commit();
        session.close();

        ArrayList<Knjiga> trenutno = new ArrayList<>();

        for (int i = 0; i < pr.size(); i++) {
            for (int j = 0; j < sveKnjige.size(); j++) {
                if (pr.get(i).getIdknjiga() == sveKnjige.get(j).getIdknjiga()) {
                    trenutno.add(sveKnjige.get(j));
                }
            }
        }

        return trenutno;

    }

    private ArrayList<Knjiga> lista() {
        ArrayList<ListaCitanje> pr = new ArrayList<>();
        ArrayList<Knjiga> sveKnjige = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(ListaCitanje.class);
        pr = (ArrayList<ListaCitanje>) c.add(Restrictions.eq("iduser", user.getIdUser())).list();

        Criteria cr = session.createCriteria(Knjiga.class);
        sveKnjige = (ArrayList<Knjiga>) cr.list();

        session.getTransaction().commit();
        session.close();

        ArrayList<Knjiga> lista = new ArrayList<>();

        for (int i = 0; i < pr.size(); i++) {
            for (int j = 0; j < sveKnjige.size(); j++) {
                if (pr.get(i).getIdknjiga() == sveKnjige.get(j).getIdknjiga()) {
                    lista.add(sveKnjige.get(j));
                }
            }
        }

        return lista;

    }

    public void idi_na_user(int id) throws IOException {

        //nadji user u sistemu i zapamti je
        poruka = "";
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", id)).uniqueResult();

        s.getTransaction().commit();
        s.close();

        if (baseUser != null) {
            user = baseUser;
        }

        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();
       
        
        

        FacesContext.getCurrentInstance().getExternalContext().redirect("user.xhtml");

    }
      public void idi_na_user2(String username) throws IOException {

        //nadji user u sistemu i zapamti je
        poruka = "";
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("username", username)).uniqueResult();

        s.getTransaction().commit();
        s.close();

        if (baseUser != null) {
            user = baseUser;
        }

        procitaneKnjige = procitane();
        listaCitanje = lista();
        trenutnoCita = trenutno();
        komentari = komentari1();
        obevestenja = svaObavestenja();

        FacesContext.getCurrentInstance().getExternalContext().redirect("user.xhtml");

    }
      
       public String getPracenjePoruka() {
        return pracenjePoruka;
    }

    public void setPracenjePoruka(String pracenjePoruka) {
        this.pracenjePoruka = pracenjePoruka;
    }
    
    

    public PieChartModel getPieChartModel() {
        return pieChartModel;
    }

    public void setPieChartModel(PieChartModel pieChartModel) {
        this.pieChartModel = pieChartModel;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ArrayList<Knjiga> getProcitaneKnjige() {
        return procitaneKnjige;
    }

    public void setProcitaneKnjige(ArrayList<Knjiga> procitaneKnjige) {
        this.procitaneKnjige = procitaneKnjige;
    }

    public ArrayList<Knjiga> getTrenutnoCita() {
        return trenutnoCita;
    }

    public void setTrenutnoCita(ArrayList<Knjiga> trenutnoCita) {
        this.trenutnoCita = trenutnoCita;
    }

    public ArrayList<Knjiga> getListaCitanje() {
        return listaCitanje;
    }

    public void setListaCitanje(ArrayList<Knjiga> listaCitanje) {
        this.listaCitanje = listaCitanje;
    }

    public ArrayList<String> getZanrovi() {
        return zanrovi;
    }

    public void setZanrovi(ArrayList<String> zanrovi) {
        this.zanrovi = zanrovi;
    }

    public ArrayList<Komentar> getKomentari() {
        return komentari;
    }

    public void setKomentari(ArrayList<Komentar> komentari) {
        this.komentari = komentari;
    }

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    public void nazad2() throws IOException {
        procenat = 0;
        brojProcitanih1 = 0;
        brojStrana1 = 100;
          porukaKomentar = "";
          pracenjePoruka = "";
        komentar = "";
        ocena = 0;


        poruka = "";
        FacesContext.getCurrentInstance().getExternalContext().redirect("knjige.xhtml");

    }
    
    public void cisti() {
        pracenjePoruka = "";
        procenat = 0;
        brojProcitanih1 = 0;
        brojStrana1 = 100;
        porukaKomentar = "";
        komentar = "";
        ocena = 0;
        poruka = "";
        barPoruka = "";
        procenat = 0;
        
        

        
    }

    public void nazad1(String tip) throws IOException {
        pracenjePoruka = "";
        procenat = 0;
        brojProcitanih1 = 0;
        brojStrana1 = 100;
        porukaKomentar = "";
        komentar = "";
        ocena = 0;

        poruka = "";
        if (tip.equals("administrator")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml");

        } else if (tip.equals("moderator")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml");

        } else if (tip.equals("korisnik")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");

        } else {
            FacesContext.getCurrentInstance().getExternalContext().redirect("gost.xhtml");

        }

    }

    public int getBrojStrana() {
        return brojStrana;
    }

    public void setBrojStrana(int brojStrana) {
        this.brojStrana = brojStrana;
    }

    public int getBrojProcitanih() {
        return brojProcitanih;
    }

    public void setBrojProcitanih(int brojProcitanih) {
        this.brojProcitanih = brojProcitanih;
    }

    public String getBarPoruka() {
        return barPoruka;
    }

    public void setBarPoruka(String barPoruka) {
        this.barPoruka = barPoruka;
    }

    public int getBrojStrana1() {
        return brojStrana1;
    }

    public void setBrojStrana1(int brojStrana1) {
        this.brojStrana1 = brojStrana1;
    }

    public int getBrojProcitanih1() {
        return brojProcitanih1;
    }

    public void setBrojProcitanih1(int brojProcitanih1) {
        this.brojProcitanih1 = brojProcitanih1;
    }

    public double getProcenat() {
        return procenat;
    }

    public void setProcenat(double procenat) {
        this.procenat = procenat;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public String getPorukaKomentar() {
        return porukaKomentar;
    }

    public void setPorukaKomentar(String porukaKomentar) {
        this.porukaKomentar = porukaKomentar;
    }
    
    public ArrayList<Obavestenje> getObevestenja() {
        return obevestenja;
    }

    public void setObevestenja(ArrayList<Obavestenje> obevestenja) {
        this.obevestenja = obevestenja;
    }
    
    
    
    


}
