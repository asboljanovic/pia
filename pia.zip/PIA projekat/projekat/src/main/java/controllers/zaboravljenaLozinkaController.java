/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.User;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.hibernate.Criteria;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class zaboravljenaLozinkaController {

    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    private String poruka;

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    public void posaljiMejl() throws Exception {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session s = sf.openSession();
        s.beginTransaction();

        Criteria c = s.createCriteria(User.class);

        User user = (User) c.add(Restrictions.eq("email", email)).uniqueResult();

        if (user == null) {
            poruka = "Korisnik ne postoji u sistemu!";
            return;
        }
        s.close();

        poruka = "Saljem mejl";
        sendMail();
        poruka = "Mejl poslat";

        poruka = "";
        email = "";

        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

    }

    String from = "asboljanovic@gmail.com";

    String subject = "Ljubitelji knjiga - zaboravljena lozinka";
    String message = "http://localhost:8080/projekat/faces/zaboravljenaLozinka.xhtml";

    public void sendMail() {
        try {
            Properties props = System.getProperties();
            // -- Attaching to default Session, or we could start a new one --
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
            props.put("mail.smtp.socketFactory.port", "465");
            props.put("mail.smtp.socketFactory.class",
                    "javax.net.ssl.SSLSocketFactory");
            Authenticator auth = new SMTPAuthenticator();
            Session session = Session.getInstance(props, auth);
            // -- Create a new message --
            Message msg = new MimeMessage(session);
            // -- Set the FROM and TO fields --
            msg.setFrom(new InternetAddress(from));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email, false));
            msg.setSubject(subject);
            msg.setContent("<h1><b> Zaboravljena lozinka</b> </h1> <br/><br/>"
                    + "Postovani, <br/><br/>"
                    + "Ukoliko ste zaboravili lozinku, klikom na link ispod mozete je resetovati.<br/><br/>"
                    + "Srdacan pozdrav! <br/><br/>"
                    + "http://localhost:8080/projekat/faces/resetovanjeLozinke.xhtml ", "text/html");
            // -- Set some other header information --
            msg.setHeader("MyMail", "Mr. XYZ");
            msg.setSentDate(new Date());
            // -- Send the message --
            Transport.send(msg);

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Exception " + ex);

        }
    }

// Also include an inner class that is used for authentication purposes
    private class SMTPAuthenticator extends javax.mail.Authenticator {

        @Override
        public PasswordAuthentication getPasswordAuthentication() {
            String username = "asboljanovic@gmail.com";           // specify your email id here (sender's email id)
            String password = "grovestreet";                                      // specify your password here
            return new PasswordAuthentication(username, password);
        }
    }

}
