/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Pracenje;
import entities.User;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.file.UploadedFile;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class loginController {

    private String username;
    private String password;
    private String message = "";
    User ulogovani = null;
    
    public void postaviUlogovanog(String username) {
         SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        Criteria cr = s.createCriteria(User.class);
        User user = (User) cr.add(Restrictions.eq("username", username)).uniqueResult();
        
        if(user!= null) {
            ulogovani = user;
        }
        s.getTransaction().commit();
        s.close();

        
    }
    
    public void izloguj() {
        ulogovani = null;
    }
    
    
    public boolean gost() {
        if(ulogovani == null) {
            return true;
        } else return false;
    }
    
    
    public boolean ulogovan(int id) {
        if(ulogovani.getIdUser() == id) {
            return true;
        }
        return false;
    }

    public User getUlogovani() {
        return ulogovani;
    }

    public void setUlogovani(User ulogovani) {
        this.ulogovani = ulogovani;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void logout() throws IOException {
        ulogovani = null;
        poruka1 = "";
        poruka2 = "";
        poruka3 = "";
        poruka4 = "";
        poruka5 = "";
        poruka6 = "";
        poruka7 = "";
        poruka8 = "";
        ime = "";
        prezime = "";
        datum = null;
        slika = null;
        email = "";
        grad = "";
        drzava= "";
        usernameM = "";
         pracenjePoruka = "";
        pratim.clear();
        pratimUsername.clear();

        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

    }
    private String pracenjePoruka = "";

      public void zapratiKorisnika(int idpratilac, int idpracen) {
           SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Pracenje.class);
          ArrayList<Pracenje> pracenja = (ArrayList<Pracenje>) cr.add(Restrictions.eq("idpratilac",idpratilac )).list();
          
          for(int i = 0 ;i < pracenja.size(); i++) {
              if(pracenja.get(i).getIdpracen() == idpracen) {
                  pracenjePoruka = "Korisnik je već zapraćen!";
                  return;
              }
          }
          
          Pracenje pr = new Pracenje();
          pr.setIdpracen(idpracen);
          pr.setIdpratilac(idpratilac);
          
          Criteria crr = s.createCriteria(User.class);
          User user = (User) crr.add(Restrictions.eq("idUser",idpracen )).uniqueResult();
          
          pratim.add(user);
          pratimUsername.add(user.getUsername());
          pracenjePoruka = "Zapratili ste korisnika ";
              s.save(pr);
                s.getTransaction().commit();
                s.close();
                
               
          
          
        
        
        
    }
    
    

    public void login() throws IOException {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        Criteria cr = s.createCriteria(User.class);
        User user = (User) cr.add(Restrictions.eq("username", username)).uniqueResult();
       

        if (user == null) {
            message = "Username je netačan ili ne postoji! Pokušati ponovo!";
            return;
        }

        if (!password.equals(user.getPassword())) {
            message = "Uneta šifra nije validna! Pokušati ponovo!";
            return;
        }

        ulogovani = user;
        
         Date date = new Date();
        user.setAktivan(date);
        s.save(user);
        s.getTransaction().commit();
        s.close();

        FacesContext fc = FacesContext.getCurrentInstance();
        HttpSession hs = (HttpSession) fc.getExternalContext().getSession(false);
        hs.setAttribute("user", user);

        pratim = zapracene();
        String tip = user.getTip();

        if ("administrator".equals(tip)) {
            message = "";
            FacesContext.getCurrentInstance().getExternalContext().redirect("faces/administrator.xhtml");
        } else if ("moderator".equals(tip)) {
            message = "";
            FacesContext.getCurrentInstance().getExternalContext().redirect("faces/moderator.xhtml");

        } else if ("korisnik".equals(tip)) {
            message = "";
            FacesContext.getCurrentInstance().getExternalContext().redirect("faces/korisnik.xhtml");

        }

    }

    public void nazad1() throws IOException {
        
      
        poruka1 = "";
        poruka2 = "";
        poruka3 = "";
        poruka4 = "";
        poruka5 = "";
        poruka6 = "";
        poruka7 = "";
        poruka8 = "";
        ime = "";
        prezime = "";
        datum = null;
        slika = null;
        email = "";
        grad = "";
        drzava= "";
        usernameM = "";
         pracenjePoruka = "";
        pratim.clear();
        pratimUsername.clear();
        
        
        
        
        if (ulogovani != null) {
            if (ulogovani.getTip().equals("administrator")) {
                FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml");

            } else if (ulogovani.getTip().equals("moderator")) {
                FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml");

            } else if (ulogovani.getTip().equals("korisnik")) {
                FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");

            }
        } else {
            FacesContext.getCurrentInstance().getExternalContext().redirect("gost.xhtml");

        }
    }

   

    public StreamedContent getRealPhoto(byte[] photo) throws SQLException, IOException {

        if (photo != null) {
            InputStream is = new ByteArrayInputStream((byte[]) photo);
            DefaultStreamedContent newPhoto = new DefaultStreamedContent(is, "image/jpg");

            return newPhoto;
        }
        return null;
    }

    public boolean registrovan(String tip) {
        if (tip.equals("administrator") || tip.equals("moderator") || tip.equals("korisnik")) {
            return true;
        }
        return false;

    }

    // MENJANJE PODATAKA
    private String ime;
    private String prezime;
    private String usernameM;

    private String grad;
    private String email;
    private byte[] slika;
    private Date datum;
    private String drzava;
    private String poruka1 = "";
    private String poruka2 = "";
    private String poruka3 = "";
    private String poruka4 = "";
    private String poruka5 = "";
    private String poruka6 = "";
    private String poruka7 = "";
    private String poruka8 = "";

    public void promeniIme() {
        if (ime.equals("")) {
            poruka1 = "Uneti ime! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        baseUser.setIme(ime);
        ulogovani.setIme(ime);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka1 = "Ime uspešno promenjeno!";

    }

    public void promeniPrezime() {
        if (prezime.equals("")) {
            poruka2 = "Uneti prezime! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        baseUser.setPrezime(prezime);
        ulogovani.setPrezime(prezime);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka2 = "Prezime uspešno promenjeno!";

    }

    public void promeniUsername() {
        if (usernameM.equals("")) {
            poruka7 = "Uneti username! ";
            return;
        }

        ArrayList<User> users = new ArrayList<>();
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();

        Criteria c = s.createCriteria(User.class);
        users = (ArrayList<User>) c.list();

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(usernameM)) {
                poruka7 = "Username je zauzet! ";
                return;
            }
        }

        baseUser.setUsername(usernameM);
        ulogovani.setUsername(usernameM);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka7 = "Username uspešno promenjen!";

    }

    public void promeniGrad() {
        if (grad.equals("")) {
            poruka5 = "Uneti grad! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        baseUser.setGrad(grad);
        ulogovani.setGrad(grad);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka5 = "Grad uspešno promenjen!";

    }

    public void promeniDrzavu() {
        if (drzava.equals("")) {
            poruka6 = "Uneti državu! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        baseUser.setDrzava(drzava);
        ulogovani.setDrzava(drzava);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka6 = "Država uspešno promenjena!";

    }

    public void promeniEmail() {
        if (email.equals("")) {
            poruka8 = "Uneti e-mail! ";
            return;
        }

        if (!email.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$")) {
            poruka8 = "Uneti e-mail nije u odgovarajućem obliku! ";
            return;

        }
        ArrayList<User> users = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        Criteria c = s.createCriteria(User.class);
        users = (ArrayList<User>) c.list();

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getEmail().equals(email)) {
                poruka8 = "E-mail je zauzet! ";
                return;
            }
        }
        baseUser.setEmail(email);
        ulogovani.setEmail(email);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka8 = "E-mail uspešno promenjen!";

    }

    public void promeniDatum() {
        if (datum == null) {
            poruka4 = "Uneti datum! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        baseUser.setDatum(datum);
        ulogovani.setDatum(datum);
        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka4 = "Datum rođenja uspešno promenjeno!";

    }

    public void promeniSliku() {
        if (slika == null) {
            poruka3 = "Nije dodata nijedna slika! ";
            return;
        }
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("idUser", ulogovani.getIdUser())).uniqueResult();
        baseUser.setSlika(slika);

        s.save(baseUser);
        s.getTransaction().commit();
        s.close();

        poruka3 = "Slika uspešno promenjena!";

    }

    public void ucitajSlikuMenjaj(FileUploadEvent event) {
        UploadedFile file = event.getFile();

        if (file != null) {
            slika = file.getContent();

        }
    }

    public String getUsernameM() {
        return usernameM;
    }

    public void setUsernameM(String usernameM) {
        this.usernameM = usernameM;
    }

    public String getPoruka8() {
        return poruka8;
    }

    public void setPoruka8(String poruka8) {
        this.poruka8 = poruka8;
    }

    public String getDrzava() {
        return drzava;
    }

    public void setDrzava(String drzava) {
        this.drzava = drzava;
    }

    public String getPoruka1() {
        return poruka1;
    }

    public void setPoruka1(String poruka1) {
        this.poruka1 = poruka1;
    }

    public String getPoruka2() {
        return poruka2;
    }

    public void setPoruka2(String poruka2) {
        this.poruka2 = poruka2;
    }

    public String getPoruka3() {
        return poruka3;
    }

    public void setPoruka3(String poruka3) {
        this.poruka3 = poruka3;
    }

    public String getPoruka4() {
        return poruka4;
    }

    public void setPoruka4(String poruka4) {
        this.poruka4 = poruka4;
    }

    public String getPoruka5() {
        return poruka5;
    }

    public void setPoruka5(String poruka5) {
        this.poruka5 = poruka5;
    }

    public String getPoruka6() {
        return poruka6;
    }

    public void setPoruka6(String poruka6) {
        this.poruka6 = poruka6;
    }

    public String getPoruka7() {
        return poruka7;
    }

    public void setPoruka7(String poruka7) {
        this.poruka7 = poruka7;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
    
    //OSOBE KOJE ULOGOVANA OSOBA PRATI 
    
     ArrayList<User> pratim = new ArrayList<User>();
     ArrayList<String> pratimUsername = new ArrayList<String>();

      private ArrayList<User> zapracene() {
        ArrayList<User> zapracene = new ArrayList<>();
        ArrayList<Pracenje> pracenje = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Pracenje.class);
        pracenje = (ArrayList<Pracenje>) c.add(Restrictions.eq("idpratilac", ulogovani.getIdUser())).list();
        
        for(int i = 0; i < pracenje.size(); i++) {
             Criteria cr = session.createCriteria(User.class);
              User base = (User) cr.add(Restrictions.eq("idUser", pracenje.get(i).getIdpracen())).uniqueResult();
              zapracene.add(base);
              pratimUsername.add(base.getUsername());
        }

       
      

        session.getTransaction().commit();
        session.close();

       return zapracene;

      }

      
    public ArrayList<User> getPratim() {
        return pratim;
    }

    public void setPratim(ArrayList<User> pratim) {
        this.pratim = pratim;
    }
    
    public ArrayList<String> getPratimUsername() {
        return pratimUsername;
    }

    public void setPratimUsername(ArrayList<String> pratimUsername) {
        this.pratimUsername = pratimUsername;
    }

     
    public String getPracenjePoruka() {
        return pracenjePoruka;
    }

    public void setPracenjePoruka(String pracenjePoruka) {
        this.pracenjePoruka = pracenjePoruka;
    }
    
}
