/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Aktivnost;
import entities.Desavanje;
import entities.Odobrenje;
import entities.Poruka;
import entities.Ucesnik;
import entities.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.primefaces.event.FlowEvent;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class desavanjeController {

    private String nazivP, nazivJ;
    private Date pocetakP, krajP, pocetakJ, krajJ;
    private String opisP, opisJ;
    private int aktivnoP, aktivnoJ;
    private String porukaP = "", porukaUcesnik = "", porukaJ = "";
    private String ucesnik;
    ArrayList<Desavanje> svaDesavanja = svaDesavanja();
    ArrayList<Desavanje> aktivnaIBuducaDesavanja = svaAktDesavanja();
    ArrayList<String> ucesnici = new ArrayList<String>();
    ArrayList<Odobrenje> odobrenja = new ArrayList<Odobrenje>();
    private String porukaO = "";
    ArrayList<Aktivnost> aktivnosti = new ArrayList<Aktivnost>();
     ArrayList<Poruka> poruke = new ArrayList<Poruka>();
    private String nazivA;
    private Date datumA;
    private String porukaA = "";
    private String tekst;
    private String porukaT = "";

   

    private Desavanje desavanje = null;
    
    private ArrayList<Desavanje> svaAktDesavanja() {
        ArrayList<Desavanje> desavanja = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Desavanje.class);
        desavanja = (ArrayList<Desavanje>) c.list();

        session.getTransaction().commit();
        session.close();
        ArrayList<Desavanje> desavanjaA = new ArrayList<>();

        for(int i =0; i<desavanja.size();i++) {
            Date sada = new Date();
            if(desavanja.get(i).getKraj() != null) {
            if(desavanja.get(i).getKraj().after(sada) && (desavanja.get(i).getPocetak().before(sada))) {
                desavanjaA.add(desavanja.get(i));
            } }
            else{
                 if((desavanja.get(i).getPocetak().before(sada))) {
                desavanjaA.add(desavanja.get(i));
            
                
            }
            
        } }
        return desavanjaA;

    }
    
     public void dodajPoruku(int id ,String username) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        
        if (tekst.equals("")) {
            porukaT = "Tekst poruke je obavezan!";
            return;
        }

      Poruka p = new Poruka();
      p.setIddesavanje(id);
      p.setTekst(tekst);
      p.setUsername(username);

        session.save(p);

        t.commit();
        session.close();
        poruke.add(p);
        porukaT = "Uspešno uneta poruka!";
        
        aktivnosti = sveAktivnosti();
        poruke = svePoruke();
             odobrenja = svaOdobrenja();
        
        

    }

    public void dodajAktivnost(int id) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        if (datumA == null) {
            porukaA = "Datum je obavezan!";
            return;
        }
        if (nazivA.equals("")) {
            porukaA = "Opis je obavezan!";
            return;

        }
        if (datumA.before(desavanje.getPocetak())) {
            porukaA = "Datum aktivnosti ne može da bude pre početka dešavanja!";
            return;
        }
        
        if(desavanje.getKraj() != null) {
              if (datumA.after(desavanje.getKraj())) {
            porukaA = "Datum aktivnosti ne može da bude posle kraja dešavanja!";
            return;
        }
        }

        for (int i = 0; i < aktivnosti.size(); i++) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            cal1.setTime(aktivnosti.get(i).getDatum());
            cal2.setTime(datumA);
            boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                    && cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);

            if (sameDay) {

                porukaA = "Označeni datum je zauzet!";
                return;
            }

        }

        Aktivnost a = new Aktivnost();
        a.setAktivnost(nazivA);
        a.setDatum(datumA);
        a.setIddesavanje(id);

        session.save(a);
         porukaA = "Uspešno uneta aktivnost!";

        t.commit();
        session.close();
        aktivnosti.add(a);
        
        
        aktivnosti = sveAktivnosti();
        poruke = svePoruke();
             odobrenja = svaOdobrenja();

    }

    public void posaljiZahtev(String username) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria cr = session.createCriteria(Odobrenje.class);
        ArrayList<Odobrenje> oo = (ArrayList<Odobrenje>) cr.add(Restrictions.eq("usernameZahtev", username)).list();

        for (int i = 0; i < oo.size(); i++) {
            if (oo.get(i).getIddesavanje() == desavanje.getIddesavanje()) {
                porukaO = "Već ste poslali zahtev. Čeka se potvrda!";
                return;
            }
        }

        Odobrenje o = new Odobrenje();
        o.setIddesavanje(desavanje.getIddesavanje());
        o.setUsernameZahtev(username);

        porukaO = "Zahtev uspešno poslat!";
        session.save(o);
        t.commit();
        session.close();
        
        
        aktivnosti = sveAktivnosti();
        poruke = svePoruke();
             odobrenja = svaOdobrenja();

    }

    public void prihvati(int id) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(Odobrenje.class);
        Odobrenje o = (Odobrenje) c.add(Restrictions.eq("idodobrenje", id)).uniqueResult();

        Criteria cr = session.createCriteria(User.class);
        User us = (User) cr.add(Restrictions.eq("username", o.getUsernameZahtev())).uniqueResult();

        Ucesnik u = new Ucesnik();
        u.setIddesavanje(o.getIddesavanje());
        u.setIduser(us.getIdUser());

        session.save(u);

        t.commit();
        session.close();

        odbij(id);

    }

    public void odbij(int id) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(Odobrenje.class);
        Odobrenje o = (Odobrenje) c.add(Restrictions.eq("idodobrenje", id)).uniqueResult();
        session.delete(o);
        session.flush();
        t.commit();
        session.close();

        
        aktivnosti = sveAktivnosti();
        poruke = svePoruke();
             odobrenja = svaOdobrenja();

    }

    public void zatvori() {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Desavanje.class);
        Desavanje d = (Desavanje) cr.add(Restrictions.eq("iddesavanje", desavanje.getIddesavanje())).uniqueResult();

        d.setAktivno(0);
        s.save(d);
        s.getTransaction().commit();
        s.close();

        if (d != null) {
            desavanje = d;
        }

    }

    public void aktiviraj() {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Desavanje.class);
        Desavanje d = (Desavanje) cr.add(Restrictions.eq("iddesavanje", desavanje.getIddesavanje())).uniqueResult();

        d.setAktivno(1);
        s.save(d);
        s.getTransaction().commit();
        s.close();

        if (d != null) {
            desavanje = d;
        }

    }

    public boolean privatnoJe() {
        if (desavanje.getTip().equals("privatno")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean javnoJe() {
        if (desavanje.getTip().equals("javno")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean zavrsenoJe() {
        Date sad = new Date();
        if (desavanje.getKraj() != null) {
            if (desavanje.getKraj().before(sad)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public boolean ucestvuje(int id) {
        ArrayList<Ucesnik> ucestvuje = new ArrayList<>();
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Ucesnik.class);
        ucestvuje = (ArrayList<Ucesnik>) cr.add(Restrictions.eq("iduser", id)).list();

        s.getTransaction().commit();
        s.close();

        for (int i = 0; i < ucestvuje.size(); i++) {
            if (ucestvuje.get(i).getIddesavanje() == desavanje.getIddesavanje()) {
                return true;
            }

        }
        return false;

    }

    public boolean aktivnoJe() {
        Date sada = new Date();
        if (sada.before(desavanje.getPocetak())) {
            return false;
        }
        if (desavanje.getKraj() != null) {
            if (sada.after(desavanje.getKraj())) {
                return false;
            }
        }
        return true;
    }

    public void idi_na_desavanje(int id) throws IOException {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();

        Criteria cr = s.createCriteria(Desavanje.class);
        Desavanje d = (Desavanje) cr.add(Restrictions.eq("iddesavanje", id)).uniqueResult();

        s.getTransaction().commit();
        s.close();

        if (d != null) {
            desavanje = d;
        }
   
        aktivnosti = sveAktivnosti();
        poruke = svePoruke();
             odobrenja = svaOdobrenja();

        FacesContext.getCurrentInstance().getExternalContext().redirect("desavanjeStranica.xhtml");

    }

    private ArrayList<Odobrenje> svaOdobrenja() {
        ArrayList<Odobrenje> od = new ArrayList<Odobrenje>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Odobrenje.class);
        od = (ArrayList<Odobrenje>) c.add(Restrictions.eq("iddesavanje", desavanje.getIddesavanje())).list();

        session.getTransaction().commit();
        session.close();

        return od;

    }

    private ArrayList<Desavanje> svaDesavanja() {
        ArrayList<Desavanje> desavanja = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Desavanje.class);
        desavanja = (ArrayList<Desavanje>) c.list();

        session.getTransaction().commit();
        session.close();

        return desavanja;

    }
    
    

    private ArrayList<Aktivnost> sveAktivnosti() {
        ArrayList<Aktivnost> akt = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Aktivnost.class);
        akt = (ArrayList<Aktivnost>) c.add(Restrictions.eq("iddesavanje", desavanje.getIddesavanje())).list();

        session.getTransaction().commit();
        session.close();

        return akt;

    }
     private ArrayList<Poruka> svePoruke() {
        ArrayList<Poruka> por = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Poruka.class);
       por = (ArrayList<Poruka>) c.add(Restrictions.eq("iddesavanje", desavanje.getIddesavanje())).list();

        session.getTransaction().commit();
        session.close();

        return por;

    }

    public void unesiUcesnika() {
        if (ucesnici.contains(ucesnik)) {
            porukaUcesnik = "Učesnik je već dodat!";
            return;
        }
        ucesnici.add(ucesnik);
        porukaUcesnik = "Učesnik uspešno dodat!";
    }

    public void napravi_javno_desavanje(String username) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Desavanje d = new Desavanje();
        d.setNaziv(nazivJ);
        if (pocetakJ == null) {
            Date dd = new Date();
            pocetakJ = dd;
            d.setPocetak(dd);
        } else {
            d.setPocetak(pocetakJ);
        }
        if (krajJ != null) {
            if (krajJ.before(pocetakJ) || krajJ.equals(pocetakJ)) {
                porukaJ = "Kraj ne može da bude pre početka!";
                return;
            }
            d.setKraj(krajJ);
        }

        d.setAktivno(1);
        d.setKreator(username);
        d.setOpis(opisJ);
        d.setTip("javno");

    

        porukaJ = "Uspešno napravljeno dešavanje!";
        session.save(d);

        t.commit();
        session.close();
        svaDesavanja = svaDesavanja();
        aktivnaIBuducaDesavanja = svaAktDesavanja();

    }

    public void napravi_privatno_desavanje(String username) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Desavanje d = new Desavanje();
        d.setNaziv(nazivP);
        if (pocetakP == null) {
            Date dd = new Date();
            pocetakP = dd;
            d.setPocetak(dd);
        } else {
            d.setPocetak(pocetakP);
        }
        if (krajP != null) {
            if (krajP.before(pocetakP) || krajP.equals(pocetakP)) {
                porukaP = "Kraj ne može da bude pre početka!";
                return;
            }
            d.setKraj(krajP);
        }

        d.setAktivno(1);
        d.setKreator(username);
        d.setOpis(opisP);
        d.setTip("privatno");
        Criteria c = session.createCriteria(Desavanje.class);
        ArrayList<Desavanje> desavanje = (ArrayList<Desavanje>) c.list();
        int iddesavanje;
        if (desavanje.size() != 0) {
            iddesavanje = desavanje.get(desavanje.size() - 1).getIddesavanje() + 1;
        } else {
            iddesavanje = 1;
        }
        if (ucesnici.size() != 0) {
            for (int i = 0; i < ucesnici.size(); i++) {
                Ucesnik u = new Ucesnik();

                Session ss = sf.openSession();
                ss.beginTransaction();
                Criteria cr = session.createCriteria(User.class);
                User uu = (User) cr.add(Restrictions.eq("username", ucesnici.get(i))).uniqueResult();
                u.setIddesavanje(iddesavanje);
                u.setIduser(uu.getIdUser());
                ss.save(u);
                ss.getTransaction().commit();
                ss.clear();
            }

        }
        

        porukaP = "Uspešno napravljeno dešavanje!";
        session.save(d);

        t.commit();
        session.close();
        svaDesavanja = svaDesavanja();
        aktivnaIBuducaDesavanja = svaAktDesavanja();
       

    }

    public void nazad(String tip) throws IOException {

        nazivP = "";
        pocetakP = null;
        krajP = null;
        opisP = "";
        porukaP = "";
        nazivJ = "";
        pocetakJ = null;
        krajJ = null;
        porukaJ = "";
        opisJ = "";
        ucesnici.clear();
        ucesnik = "";
        porukaUcesnik = "";
        desavanje = null;
        porukaO = "";
        nazivA = "";
        porukaA = "";
        datumA = null;
        porukaT = "";
        tekst = "";
        porukaA = "";
        porukaJ = "";
        porukaO = "";
        porukaP = "";
        porukaT = "";
       


        if (tip.equals("administrator")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml");

        } else if (tip.equals("moderator")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml");

        } else if (tip.equals("korisnik")) {
            FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");

        }
    }
     public void nazad2() throws IOException {

        nazivP = "";
        pocetakP = null;
        krajP = null;
        opisP = "";
        porukaP = "";
        nazivJ = "";
        pocetakJ = null;
        krajJ = null;
        porukaJ = "";
        opisJ = "";
        ucesnici.clear();
        ucesnik = "";
        porukaUcesnik = "";
        desavanje = null;
        porukaO = "";
        nazivA = "";
        porukaA = "";
        datumA = null;
        porukaT = "";
        tekst = "";
        porukaA = "";
        porukaJ = "";
        porukaO = "";
        porukaP = "";
        porukaT = "";
       

      
            FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");

       
    }

    public String getPorukaP() {
        return porukaP;
    }

    public void setPorukaP(String porukaP) {
        this.porukaP = porukaP;
    }

    public String onFlowProcess(FlowEvent event) {

        return event.getNewStep();

    }

    public String getNazivP() {
        return nazivP;
    }

    public void setNazivP(String nazivP) {
        this.nazivP = nazivP;
    }

    public Date getPocetakP() {
        return pocetakP;
    }

    public void setPocetakP(Date pocetakP) {
        this.pocetakP = pocetakP;
    }

    public Date getKrajP() {
        return krajP;
    }

    public void setKrajP(Date krajP) {
        this.krajP = krajP;
    }

    public String getOpisP() {
        return opisP;
    }

    public void setOpisP(String opisP) {
        this.opisP = opisP;
    }

    public int getAktivnoP() {
        return aktivnoP;
    }

    public void setAktivnoP(int aktivnoP) {
        this.aktivnoP = aktivnoP;
    }

    public String getUcesnik() {
        return ucesnik;
    }

    public void setUcesnik(String ucesnik) {
        this.ucesnik = ucesnik;
    }

    public ArrayList<String> getUcesnici() {
        return ucesnici;
    }

    public void setUcesnici(ArrayList<String> ucesnici) {
        this.ucesnici = ucesnici;
    }

    public String getPorukaUcesnik() {
        return porukaUcesnik;
    }

    public void setPorukaUcesnik(String porukaUcesnik) {
        this.porukaUcesnik = porukaUcesnik;
    }

    public String getNazivJ() {
        return nazivJ;
    }

    public void setNazivJ(String nazivJ) {
        this.nazivJ = nazivJ;
    }

    public Date getPocetakJ() {
        return pocetakJ;
    }

    public void setPocetakJ(Date pocetakJ) {
        this.pocetakJ = pocetakJ;
    }

    public Date getKrajJ() {
        return krajJ;
    }

    public void setKrajJ(Date krajJ) {
        this.krajJ = krajJ;
    }

    public String getOpisJ() {
        return opisJ;
    }

    public void setOpisJ(String opisJ) {
        this.opisJ = opisJ;
    }

    public int getAktivnoJ() {
        return aktivnoJ;
    }

    public void setAktivnoJ(int aktivnoJ) {
        this.aktivnoJ = aktivnoJ;
    }

    public String getPorukaJ() {
        return porukaJ;
    }

    public void setPorukaJ(String porukaJ) {
        this.porukaJ = porukaJ;
    }

    public ArrayList<Desavanje> getSvaDesavanja() {
        return svaDesavanja;
    }

    public void setSvaDesavanja(ArrayList<Desavanje> svaDesavanja) {
        this.svaDesavanja = svaDesavanja;
    }

    public Desavanje getDesavanje() {
        return desavanje;
    }

    public void setDesavanje(Desavanje desavanje) {
        this.desavanje = desavanje;
    }

    public ArrayList<Odobrenje> getOdobrenja() {
        return odobrenja;
    }

    public void setOdobrenja(ArrayList<Odobrenje> odobrenja) {
        this.odobrenja = odobrenja;
    }

    public String getPorukaO() {
        return porukaO;
    }

    public void setPorukaO(String porukaO) {
        this.porukaO = porukaO;
    }

    public ArrayList<Aktivnost> getAktivnosti() {
        return aktivnosti;
    }

    public void setAktivnosti(ArrayList<Aktivnost> aktivnosti) {
        this.aktivnosti = aktivnosti;
    }

    public String getNazivA() {
        return nazivA;
    }

    public void setNazivA(String nazivA) {
        this.nazivA = nazivA;
    }

    public Date getDatumA() {
        return datumA;
    }

    public void setDatumA(Date datumA) {
        this.datumA = datumA;
    }

    public String getPorukaA() {
        return porukaA;
    }

    public void setPorukaA(String porukaA) {
        this.porukaA = porukaA;
    }
    
    public String getTekst() {
        return tekst;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }
    
    public ArrayList<Poruka> getPoruke() {
        return poruke;
    }

    public void setPoruke(ArrayList<Poruka> poruke) {
        this.poruke = poruke;
    }

     public String getPorukaT() {
        return porukaT;
    }

    public void setPorukaT(String porukaT) {
        this.porukaT = porukaT;
    }
    
    
    public ArrayList<Desavanje> getAktivnaIBuducaDesavanja() {
        return aktivnaIBuducaDesavanja;
    }

    public void setAktivnaIBuducaDesavanja(ArrayList<Desavanje> aktivnaIBuducaDesavanja) {
        this.aktivnaIBuducaDesavanja = aktivnaIBuducaDesavanja;
    }


}
