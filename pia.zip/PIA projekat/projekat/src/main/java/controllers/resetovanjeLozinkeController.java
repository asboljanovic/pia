/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.User;
import java.io.IOException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class resetovanjeLozinkeController {
    
    private String username;
    private String new_password;
    private String confirm_new_password;
    private String poruka;

    public String getPoruka() {
        return poruka;
    }

    public void setPoruka(String poruka) {
        this.poruka = poruka;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNew_password() {
        return new_password;
    }

    public void setNew_password(String new_password) {
        this.new_password = new_password;
    }

    public String getConfirm_new_password() {
        return confirm_new_password;
    }

    public void setConfirm_new_password(String confirm_new_password) {
        this.confirm_new_password = confirm_new_password;
    }
    
    public void promeni() throws IOException {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        
        Criteria c = s.createCriteria(User.class);
        
        User user = (User) c.add(Restrictions.eq("username", username)).uniqueResult();
        
        if(user == null) {
            poruka = "Korisnik ne postoji u sistemu!";
            return;
        }
        
        if(!new_password.equals(confirm_new_password)) {
            poruka = "Lozinke se ne poklapaju!!!";
            return;
            
        }
        
         user.setPassword(new_password);
          s.save(user);
          s.getTransaction().commit();
          s.close();
          
         
           if("administrator".equals(user.getTip())) {
                poruka = "";
                FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml");
        }else if("moderator".equals(user.getTip())) {
                poruka = "";
                FacesContext.getCurrentInstance().getExternalContext().redirect("moderator.xhtml");
          
        }else if ("korisnik".equals(user.getTip())) {
                 poruka= "";
                FacesContext.getCurrentInstance().getExternalContext().redirect("korisnik.xhtml");
          
        } 
        
        
        
        
        
        
        
    }
    
    
}
