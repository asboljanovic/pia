/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.User;
import entities.Zahtev;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import util.HibernateUtil;

/**
 *
 * @author Win10
 */
@ManagedBean
@SessionScoped
public class adminController {
     ArrayList<User> registrovaniK = registrovani();
     ArrayList<User> moderatorK = moderatori();
      ArrayList<Zahtev> zahteviK = zahtevi();
    
    
   
    
    private ArrayList<Zahtev> zahtevi() {
        ArrayList<Zahtev> zahtevi = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(Zahtev.class);
        zahtevi = (ArrayList<Zahtev>) c.list();
        session.getTransaction().commit();
        session.close();

        return zahtevi;
    }

    public ArrayList<Zahtev> getZahteviK() {
        return zahteviK;
    }

    public void setZahteviK(ArrayList<Zahtev> zahteviK) {
        this.zahteviK = zahteviK;
    }

    private ArrayList<User> moderatori() {
        ArrayList<User> users = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(User.class);
         users =  (ArrayList<User>) c.add(Restrictions.eq("tip", "moderator")).list();
        session.getTransaction().commit();
        session.close();

        return users;

    }

    public ArrayList<User> getRegistrovaniK() {
        return registrovaniK;
    }

    public void setRegistrovaniK(ArrayList<User> registrovaniK) {
        this.registrovaniK = registrovaniK;
    }

    public ArrayList<User> getModeratorK() {
        return moderatorK;
    }

    public void setModeratorK(ArrayList<User> moderatorK) {
        this.moderatorK = moderatorK;
    }
    
   
    
    private ArrayList<User> registrovani() {
        ArrayList<User> users = new ArrayList<>();

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();

        Criteria c = session.createCriteria(User.class);
         users =  (ArrayList<User>) c.add(Restrictions.eq("tip", "korisnik")).list();
        session.getTransaction().commit();
        session.close();

        return users;

    }
    
    public void idiNaKnjige() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("knjige.xhtml");
    }
    public void idiNaKorisnike() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("pretragaKorisnika.xhtml");
    }

public void idiNaZanrove() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("zanrovi.xhtml");
    }

      public void idiNaPrivilegije() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("privilegije.xhtml");
    }
      
      public void idiNaZahteve() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("zahtevi.xhtml");
    }
   

    public void idiNaAdmin() throws IOException {

        FacesContext.getCurrentInstance().getExternalContext().redirect("administrator.xhtml");
    }

    public void prihvati(String username) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(Zahtev.class);
        Zahtev z = (Zahtev) c.add(Restrictions.eq("username", username)).uniqueResult();

        User u = new User();
        u.setDatum(z.getDatum());
        u.setEmail(z.getEmail());
        u.setGrad(z.getGrad());
        u.setIme(z.getIme());
        u.setPassword(z.getPassword());
        u.setPrezime(z.getPrezime());
        u.setSlika(z.getSlika());
        u.setTip(z.getTip());
        u.setUsername(z.getUsername());
        u.setDrzava(z.getDrzava());

        session.save(u);

        t.commit();
        session.close();

        odbij(username);

    }

    public void odbij(String username) {
        
        
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction t = session.beginTransaction();

        Criteria c = session.createCriteria(Zahtev.class);
        Zahtev z = (Zahtev) c.add(Restrictions.eq("username", username)).uniqueResult();
        session.delete(z);
        
          for(int i = 0; i < zahteviK.size();i++) {
              if(zahteviK.get(i).getUsername().equals(z.getUsername())) {
                  zahteviK.remove(i);
              }
          }
       registrovaniK = registrovani();
     moderatorK = moderatori();

        session.flush();
        t.commit();
        session.close();

    }
    
    public void unapredi_u_moderatora(String username) {
         SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("username",username)).uniqueResult();
       
          baseUser.setTip("moderator");
          s.save(baseUser);
          s.getTransaction().commit();
          s.close();
          
          
          for(int i = 0; i < registrovaniK.size();i++) {
              if(registrovaniK.get(i).getUsername().equals(baseUser.getUsername())) {
                  registrovaniK.remove(i);
              }
          }
          
         
          moderatorK.add(baseUser);
        
          
          
        
    }
    
    public void u_korisnika(String username) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();
        s.beginTransaction();
        Criteria cr = s.createCriteria(User.class);
        User baseUser = (User) cr.add(Restrictions.eq("username",username)).uniqueResult();
          baseUser.setTip("korisnik");
          s.save(baseUser);
          s.getTransaction().commit();
          s.close();
          registrovaniK.add(baseUser);
         
           for(int i = 0; i < moderatorK.size();i++) {
              if(moderatorK.get(i).getUsername().equals(baseUser.getUsername())) {
                  moderatorK.remove(i);
              }
          }
        
    }

}
