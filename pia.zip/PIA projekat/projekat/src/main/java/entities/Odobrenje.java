/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name = "odobrenje")
public class Odobrenje implements Serializable {

    @Id
    @Column(name = "idodobrenje")
    private int idodobrenje;

    @Column(name = "usernameZahtev")
    private String usernameZahtev;

    @Column(name = "iddesavanje")
    private int iddesavanje;

    public int getIdodobrenje() {
        return idodobrenje;
    }

    public void setIdodobrenje(int idodobrenje) {
        this.idodobrenje = idodobrenje;
    }

    public String getUsernameZahtev() {
        return usernameZahtev;
    }

    public void setUsernameZahtev(String usernameZahtev) {
        this.usernameZahtev = usernameZahtev;
    }

  

    public int getIddesavanje() {
        return iddesavanje;
    }

    public void setIddesavanje(int iddesavanje) {
        this.iddesavanje = iddesavanje;
    }

}
