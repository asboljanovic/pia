/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name = "poruka")
public class Poruka implements Serializable {
    
    
    @Id
    @Column(name = "idporuka")
    private int idporuka;

    @Column(name = "iddesavanje")
       private int iddesavanje;
    
     @Column(name = "username")
       private String username;
     
     @Column(name = "tekst")
       private String tekst;

    public int getIdporuka() {
        return idporuka;
    }

    public void setIdporuka(int idporuka) {
        this.idporuka = idporuka;
    }

    public int getIddesavanje() {
        return iddesavanje;
    }

    public void setIddesavanje(int iddesavanje) {
        this.iddesavanje = iddesavanje;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTekst() {
        return tekst;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }
     
     
    
    
    
}
