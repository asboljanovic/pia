/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name = "desavanje")
public class Desavanje implements Serializable {

    @Id
    @Column(name = "iddesavanje")
    private int iddesavanje;

    @Column(name = "naziv")
    private String naziv;

    @Column(name = "pocetak")
    private Date pocetak;

    @Column(name = "kraj")
    private Date kraj;

    @Column(name = "opis")
    private String opis;

    @Column(name = "tip")
    private String tip;

    @Column(name = "kreator")
    private String kreator;
    
     @Column(name = "aktivno")
    private int aktivno;

    public int getIddesavanje() {
        return iddesavanje;
    }

    public void setIddesavanje(int iddesavanje) {
        this.iddesavanje = iddesavanje;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Date getPocetak() {
        return pocetak;
    }

    public void setPocetak(Date pocetak) {
        this.pocetak = pocetak;
    }

    public Date getKraj() {
        return kraj;
    }

    public void setKraj(Date kraj) {
        this.kraj = kraj;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getKreator() {
        return kreator;
    }

    public void setKreator(String kreator) {
        this.kreator = kreator;
    }

    public int getAktivno() {
        return aktivno;
    }

    public void setAktivno(int aktivno) {
        this.aktivno = aktivno;
    }
     
     

}
