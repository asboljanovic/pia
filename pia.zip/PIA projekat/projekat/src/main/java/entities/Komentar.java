/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="komentar")
public class Komentar implements Serializable {
    @Id
    @Column(name = "idkomentar")
    private int idkomentar;
    
    @Column(name = "username")
    private String username;

     
    @Column(name = "idknjiga")
    private int idknjiga;
     
    @Column(name = "ocena")
    private int ocena;
    
     @Column(name = "komentar")
    private String komentar;

    public int getIdkomentar() {
        return idkomentar;
    }

    public void setIdkomentar(int idkomentar) {
        this.idkomentar = idkomentar;
    }

   
    public int getIdknjiga() {
        return idknjiga;
    }

    public void setIdknjiga(int idknjiga) {
        this.idknjiga = idknjiga;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
      
    
    
    
    
    
    
    
    
}
