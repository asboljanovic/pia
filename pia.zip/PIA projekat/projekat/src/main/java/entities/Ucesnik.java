/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name = "ucesnik")
public class Ucesnik implements Serializable {

    @Id
    @Column(name = "iducesnik")
    private int iducesnik;

    @Column(name = "iduser")
    private int iduser;
    
    @Column(name = "iddesavanje")
    private int iddesavanje;

    public int getIducesnik() {
        return iducesnik;
    }

    public void setIducesnik(int iducesnik) {
        this.iducesnik = iducesnik;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public int getIddesavanje() {
        return iddesavanje;
    }

    public void setIddesavanje(int iddesavanje) {
        this.iddesavanje = iddesavanje;
    }
    
    

}
