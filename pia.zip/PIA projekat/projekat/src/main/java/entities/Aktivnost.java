/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name = "aktivnost")
public class Aktivnost implements Serializable {

    @Id
    @Column(name = "idaktivnost")
    private int idaktivnost;

    @Column(name = "iddesavanje")
    private int iddesavanje;
    
      @Column(name = "aktivnost")
    private String aktivnost;
      
       @Column(name = "datum")
    private Date datum;

    public int getIdaktivnost() {
        return idaktivnost;
    }

    public void setIdaktivnost(int idaktivnost) {
        this.idaktivnost = idaktivnost;
    }

    public int getIddesavanje() {
        return iddesavanje;
    }

    public void setIddesavanje(int iddesavanje) {
        this.iddesavanje = iddesavanje;
    }

    public String getAktivnost() {
        return aktivnost;
    }

    public void setAktivnost(String aktivnost) {
        this.aktivnost = aktivnost;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
      
      

}
