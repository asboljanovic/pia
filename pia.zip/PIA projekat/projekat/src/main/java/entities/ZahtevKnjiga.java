/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="zahtevknjiga")
public class ZahtevKnjiga implements Serializable {
    
    
    @Id
    @Column(name = "idzahtevknjiga")
    private int idzahtevknjiga;
    
     @Column(name = "autor")
    private String autor;
     
    @Column(name = "opis")
    private String opis;
    
     @Column(name = "zanr")
    private String zanr;
     
    @Column(name = "naziv")
    private String naziv;
     
    @Column(name = "slika")
    private byte[] slika;
    
    @Column(name = "datum")
    private Date datum;

    public int getIdzahtevknjiga() {
        return idzahtevknjiga;
    }

    public void setIdzahtevknjiga(int idzahtevknjiga) {
        this.idzahtevknjiga = idzahtevknjiga;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        this.zanr = zanr;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
    
    
     
    
    
    
}
