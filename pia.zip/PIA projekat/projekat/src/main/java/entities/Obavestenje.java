/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="obavestenje")
public class Obavestenje implements Serializable {
     
    @Id
    @Column(name = "idobavestenje")
    private int idobavestenje;
    
    @Column(name = "iduser")
    private int iduser;
    
     @Column(name = "obavestenje")
    private String obavestenje;

    public int getIdobavestenje() {
        return idobavestenje;
    }

    public void setIdobavestenje(int idobavestenje) {
        this.idobavestenje = idobavestenje;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public String getObavestenje() {
        return obavestenje;
    }

    public void setObavestenje(String obavestenje) {
        this.obavestenje = obavestenje;
    }
     
    
}
