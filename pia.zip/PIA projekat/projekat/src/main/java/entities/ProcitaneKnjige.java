/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="procitaneknjige")
public class ProcitaneKnjige implements Serializable {
    @Id
    @Column(name = "idprocitaneknjige")
    private int idprocitaneknjige;
    
    @Column(name = "iduser")
    private int iduser;
    
    @Column(name = "idknjiga")
    private int idknjiga;

    public int getIdprocitaneknjige() {
        return idprocitaneknjige;
    }

    public void setIdprocitaneknjige(int idprocitaneknjige) {
        this.idprocitaneknjige = idprocitaneknjige;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public int getIdknjiga() {
        return idknjiga;
    }

    public void setIdknjiga(int idknjiga) {
        this.idknjiga = idknjiga;
    }
    
    
    
}
