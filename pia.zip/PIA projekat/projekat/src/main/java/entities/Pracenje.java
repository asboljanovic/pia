/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="pracenje")
public class Pracenje implements Serializable {
    
    @Id
     @Column(name = "idpracenje")
    private int idpracenje;

    
     @Column(name = "idpratilac")
    private int idpratilac;
    
     @Column(name = "idpracen")
    private int idpracen; 


    public int getIdpratilac() {
        return idpratilac;
    }

    public void setIdpratilac(int idpratilac) {
        this.idpratilac = idpratilac;
    }

    public int getIdpracen() {
        return idpracen;
    }

    public void setIdpracen(int idpracen) {
        this.idpracen = idpracen;
    }
     
     
    public int getIdpracenje() {
        return idpracenje;
    }

    public void setIdpracenje(int idpracenje) {
        this.idpracenje = idpracenje;
    }
    
    
    
}
