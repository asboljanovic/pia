/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="knjiga")
public class Knjiga implements Serializable {
    
    @Id
    @Column(name = "idknjiga")
    private int idknjiga;
    
    @Column(name = "slika")
    private byte[] slika;
    
     @Column(name = "autor")
    private String autor;
     
     @Column(name = "datum")
    private Date datum;
     
     
     @Column(name = "zanr")
    private String zanr;
     
     @Column(name = "naziv")
    private String naziv;

  
     
     @Column(name = "ocena")
    private float ocena;
      
    
    @Column(name = "opis")
    private String opis;
    
     @Column(name = "dodata")
    private boolean dodata;

    public boolean isDodata() {
        return dodata;
    }

    public void setDodata(boolean dodata) {
        this.dodata = dodata;
    }
    

      public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getIdknjiga() {
        return idknjiga;
    }

    public void setIdknjiga(int idknjiga) {
        this.idknjiga = idknjiga;
    }
    
    
    
   
    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        this.zanr = zanr;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public float getOcena() {
        return ocena;
    }

    public void setOcena(float ocena) {
        this.ocena = ocena;
    }
   
      
     
     
     
     
     
     
    
    
    
    
}
