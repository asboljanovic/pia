/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */
@Entity
@Table(name="zanr")
public class Zanr implements Serializable {
     @Id
    @Column(name = "idzanr")
    private int idzanr;
    
    @Column(name = "zanr")
    private String zanr;

    public int getIdzanr() {
        return idzanr;
    }

    public void setIdzanr(int idzanr) {
        this.idzanr = idzanr;
    }

    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        this.zanr = zanr;
    }
    
}
