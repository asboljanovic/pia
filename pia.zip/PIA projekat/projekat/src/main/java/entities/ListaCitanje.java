/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Win10
 */

@Entity
@Table(name="listacitanje")
public class ListaCitanje implements Serializable {

   
    
    @Id
    @Column(name = "idlistacitanje")
    private int idlistacitanje;
    
    @Column(name = "iduser")
    private int iduser;
    
    @Column(name = "idknjiga")
    private int idknjiga;
    
     public int getIdlistacitanje() {
        return idlistacitanje;
    }

    public void setIdlistacitanje(int idlistacitanje) {
        this.idlistacitanje = idlistacitanje;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public int getIdknjiga() {
        return idknjiga;
    }

    public void setIdknjiga(int idknjiga) {
        this.idknjiga = idknjiga;
    }
    
}
